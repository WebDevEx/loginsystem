<?php

function npv_times($cashflows, $times, $intRate)
{
  $npv = 0;
  $i = 0;
  foreach($cashflows as $cf) {
    $year = $times[$i];
    $npv += $cf / pow(1 + $intRate, $year);
    $i++;
  }
  return($npv);
}
$test_cf=array();
$test_cf = [0, 500, 300, 800];
$test_times=array();
$test_times = [0, 1, 2, 3];
echo npv_times($test_cf, $test_times, 0.08)-1000; // Output: 25.663934364013

?>