<?php
session_start();
if (strlen($_SESSION['id']==0)) {
  header('location:NPV.php');
  } else{
	
?><!DOCTYPE html>
<html lang="en">

<head>

<body onload="createTable()">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>NPV CALCULATOR</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/heroic-features.css" rel="stylesheet">
</head>
<body>.



   <nav class="navbar navbar-default navbar-static-top">.
       <div class="container">.
            <div class="navbar-header">.
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">.
                   <span class="sr-only">Toggle navigation</span>.
                   <span class="icon-bar"></span>.
                   <span class="icon-bar"></span>.
                   <span class="icon-bar"></span>.
               </button>.
               <a class="navbar-brand" href="/"><strong>NPV Calculator</strong></a>.
           </div>.
           <div id="navbar" class="collapse navbar-collapse">.
               <ul class="nav navbar-nav navbar-right">.
                    <li>.
                       <a href="/"><strong>NPV Calculator</strong></a>.
                   </li>.
                    <li>.
                       <a href="/npv-vs-irr/">.
                           <Strong>NPV vs IRR</Strong> </a>.
                   </li>.
                   <li>.
                       <a href="http://irrcalculator.net/" target="_blank" rel="nofollow"><strong>IRR Calculator</strong></a>.
                   </li>.
                   <li>.
                       <a href="http://cagrcalculator.net/" target="_blank" rel="nofollow"><strong>CAGR Calculator</strong></a>.
                   </li>.
                </ul>.
           </div>.
           <!--/.nav-collapse -->.
        </div>.
    </nav>.
    <div class="container panel panel-default panel-body ">.
        <div class="text-center">.
           <h1>NPV Calculator</h1>.
           <p class="h3 text-muted">Calculate NPV or Net Present Value Online</p>.
       </div>.
        <div class="text-center table-responsive col-md-6 col-md-offset-3">.
           <form method="post" action="/result/">.
                <table class="table table-condensed table-striped table-bordered" id="tab_logic">.
                   <tbody>.
                       <tr>.
                           <td>.
                               Initial Investment.
                           </td>.
                           <td>.
                               <input class="form-control" name="iv" placeholder="10000" required>.
                           </td>.
                       </tr>.
                        <tr>.
                           <td>.
                               Discount Rate (% p.a).
                           </td>.
                           <td>.
                               <input type="number" step="0.01" class="form-control" name="dr" placeholder="8.5" required>.
                           </td>.
                       </tr>.
                       <tr>.
                           <td colspan="2" class="bg-info">.
                               <strong>Cash Flow (positive or negative)</strong>.
                           </td>.
                       </tr>.
                        <tr id='addr0'>.
                           <td>.
                               Period 1.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                       </tr>.
                        <tr id='addr1'>.
                           <td>.
                               Period 2.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                           </td>.
                       </tr>.
                        <tr id='addr2'>.
                           <td>.
                               Period 3.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                           </td>.
                       </tr>.
                        <tr id='addr3'>.
                           <td>.
                               Period 4.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                           </td>.
                       </tr>.
                        <tr id='addr4'>.
                           <td>.
                               Period 5.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                           </td>.
                       </tr>.
                        <tr id='addr5'>.
                        </tr>.
                    </tbody>.
               </table>.
                <table class="table table-condensed table-striped table-bordered">.
                    <tbody>.
                       <tr>.
                           <td colspan="2">.
                                <span>   .
                         

<p>
<input type="button" id="addRow" value="Add New Row" onclick="addRow()" />
</p>


                          <a id='delete_row' class="btn btn-primary">.
                          Delete Period</a>.

                          </span>.
                            </td>.
                       </tr>.
                        <tr>.
                           <td colspan="2">.
                              <p>
<input type="button" id="bt" value="Submit Data" onclick="submit()" />
</p>.
                           </td>.
                       </tr>.
                    </tbody>.
               </table>.
            </form>.
        </div>.
    </div>.
   
/body>.
</html>
<?php } ?>