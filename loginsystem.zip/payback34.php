<?php


session_start();
if (strlen($_SESSION['id']==0)) {
  header('location:payback34.php');
  } else{
	
?><!DOCTYPE html>
<html lang="en">

<body>







<script data-ezscrex='false' data-cfasync='false' data-pagespeed-no-defer>var __ez=__ez||{};__ez.stms=Date.now();__ez.evt={};__ez.script={};__ez.ck=__ez.ck||{};__ez.template={};__ez.template.isOrig=true;__ez.queue=(function(){var count=0,incr=0,items=[],timeDelayFired=false,hpItems=[],lpItems=[],allowLoad=true;var obj={func:function(name,funcName,parameters,isBlock,blockedBy,deleteWhenComplete,proceedIfError){var self=this;this.name=name;this.funcName=funcName;this.parameters=parameters===null?null:(parameters instanceof Array)?parameters:[parameters];this.isBlock=isBlock;this.blockedBy=blockedBy;this.deleteWhenComplete=deleteWhenComplete;this.isError=false;this.isComplete=false;this.isInitialized=false;this.proceedIfError=proceedIfError;this.isTimeDelay=false;this.process=function(){log("... func = "+name);self.isInitialized=true;self.isComplete=true;log("... func.apply: "+name);var funcs=self.funcName.split('.');var func=null;if(funcs.length>3){}else if(funcs.length===3){func=window[funcs[0]][funcs[1]][funcs[2]];}else if(funcs.length===2){func=window[funcs[0]][funcs[1]];}else{func=window[self.funcName];}
if(typeof func!=='undefined'&&func!==null){func.apply(null,this.parameters);}
if(self.deleteWhenComplete===true)delete items[name];if(self.isBlock===true){log("----- F'D: "+self.name);processAll();}}},file:function(name,path,isBlock,blockedBy,async,defer,proceedIfError){var self=this;this.name=name;this.path=path;this.async=async;this.defer=defer;this.isBlock=isBlock;this.blockedBy=blockedBy;this.isInitialized=false;this.isError=false;this.isComplete=false;this.proceedIfError=proceedIfError;this.isTimeDelay=false;this.process=function(){self.isInitialized=true;log("... file = "+name);var scr=document.createElement('script');scr.src=path;if(async===true)scr.async=true;else if(defer===true)scr.defer=true;scr.onerror=function(){log("----- ERR'D: "+self.name);self.isError=true;if(self.isBlock===true){processAll();}};scr.onreadystatechange=scr.onload=function(){var state=scr.readyState;log("----- F'D: "+self.name);if((!state||/loaded|complete/.test(state))){self.isComplete=true;if(self.isBlock===true){processAll();}}};document.getElementsByTagName('head')[0].appendChild(scr);}},fileLoaded:function(name,isComplete){this.name=name;this.path="";this.async=false;this.defer=false;this.isBlock=false;this.blockedBy=[];this.isInitialized=true;this.isError=false;this.isComplete=isComplete;this.proceedIfError=false;this.isTimeDelay=false;this.process=function(){};}};function init(){window.addEventListener("load",function(){setTimeout(function(){timeDelayFired=true;log('TDELAY -----');processAll();},5000);},false);}
function addFile(name,path,isBlock,blockedBy,async,defer,proceedIfError,priority){var item=new obj.file(name,path,isBlock,blockedBy,async,defer,proceedIfError);if(priority===true){hpItems[name]=item}else{lpItems[name]=item}
items[name]=item;checkIfBlocked(item);}
function setallowLoad(settobool){allowLoad=settobool}
function addFunc(name,func,parameters,isBlock,blockedBy,autoInc,deleteWhenComplete,proceedIfError,priority){if(autoInc===true)name=name+"_"+incr++;var item=new obj.func(name,func,parameters,isBlock,blockedBy,deleteWhenComplete,proceedIfError);if(priority===true){hpItems[name]=item}else{lpItems[name]=item}
items[name]=item;checkIfBlocked(item);}
function addTimeDelayFile(name,path){var item=new obj.file(name,path,false,[],false,false,true);item.isTimeDelay=true;log(name+' ... '+' FILE! TDELAY');lpItems[name]=item;items[name]=item;checkIfBlocked(item);}
function addTimeDelayFunc(name,func,parameters){var item=new obj.func(name,func,parameters,false,[],true,true);item.isTimeDelay=true;log(name+' ... '+' FUNCTION! TDELAY');lpItems[name]=item;items[name]=item;checkIfBlocked(item);}
function checkIfBlocked(item){if(isBlocked(item)===true||allowLoad==false)return;item.process();}
function isBlocked(item){if(item.isTimeDelay===true&&timeDelayFired===false){log(item.name+" blocked = TIME DELAY!");return true;}
if(item.blockedBy instanceof Array){for(var i=0;i<item.blockedBy.length;i++){var block=item.blockedBy[i];if(items.hasOwnProperty(block)===false){log(item.name+" blocked = "+block);return true;}else if(item.proceedIfError===true&&items[block].isError===true){return false;}else if(items[block].isComplete===false){log(item.name+" blocked = "+block);return true;}}}
return false;}
function markLoaded(filename){if(!filename||0===filename.length){return;}
if(filename in items){var item=items[filename];if(item.isComplete===true){log(item.name+' '+filename+': error loaded duplicate')}else{item.isComplete=true;item.isInitialized=true;}}else{items[filename]=new obj.fileLoaded(filename,true);}
log("Added dummyfile: "+items[filename]);}
function log(msg){var href=window.location.href;var reg=new RegExp('[?&]ezq=([^&#]*)','i');var string=reg.exec(href);var res=string?string[1]:null;if(res==="1")console.debug(msg);}
function processAll(){count++;if(count>200)return;log("let's go");processItems(hpItems);processItems(lpItems);}
function processItems(list){for(var i in list){if(list.hasOwnProperty(i)===false)continue;var item=list[i];if(item.isComplete===true||isBlocked(item)||item.isInitialized===true||item.isError===true){if(item.isError===true){log(item.name+': error')}else if(item.isComplete===true){log(item.name+': complete already')}else if(item.isInitialized===true){log(item.name+': initialized already')}}else{item.process();}}}
init();return{addFile:addFile,addDelayFile:addTimeDelayFile,addFunc:addFunc,addDelayFunc:addTimeDelayFunc,items:items,processAll:processAll,setallowLoad:setallowLoad,markLoaded:markLoaded,};})();__ez.evt.add=function(e,t,n){e.addEventListener?e.addEventListener(t,n,!1):e.attachEvent?e.attachEvent("on"+t,n):e["on"+t]=n()},__ez.evt.remove=function(e,t,n){e.removeEventListener?e.removeEventListener(t,n,!1):e.detachEvent?e.detachEvent("on"+t,n):delete e["on"+t]};__ez.script.add=function(e){var t=document.createElement("script");t.src=e,t.async=!0,t.type="text/javascript",document.getElementsByTagName("head")[0].appendChild(t)};__ez.dot={};__ez.queue.addFile('/detroitchicago/boise.js', '/detroitchicago/boise.js?gcb=194-2&cb=1', false, [], true, false, true, false);__ez.queue.addFile('/detroitchicago/memphis.js', '/detroitchicago/memphis.js?gcb=194-2&cb=7', false, [], true, false, true, false);__ez.queue.addFile('/detroitchicago/minneapolis.js', '/detroitchicago/minneapolis.js?gcb=194-2&cb=3', false, [], true, false, true, false);__ez.queue.addFile('/detroitchicago/rochester.js', '/detroitchicago/rochester.js?gcb=194-2&cb=10', false, ['/detroitchicago/memphis.js','/detroitchicago/minneapolis.js'], true, false, true, false);__ez.vep=(function(){var pixels=[],pxURL="/detroitchicago/grapefruit.gif";function AddPixel(vID,pixelData){if(__ez.dot.isDefined(vID)&&__ez.dot.isValid(pixelData)){pixels.push({type:'video',video_impression_id:vID,domain_id:__ez.dot.getDID(),t_epoch:__ez.dot.getEpoch(0),data:__ez.dot.dataToStr(pixelData)});}}
function Fire(){if(typeof document.visibilityState!=='undefined'&&document.visibilityState==="prerender"){return;}
if(__ez.dot.isDefined(pixels)&&pixels.length>0){while(pixels.length>0){var j=5;if(j>pixels.length){j=pixels.length;}
var pushPixels=pixels.splice(0,j);var pixelURL=__ez.dot.getURL(pxURL)+"?orig="+(__ez.template.isOrig===true?1:0)+"&v="+btoa(JSON.stringify(pushPixels));__ez.dot.Fire(pixelURL);}}
pixels=[];}
return{Add:AddPixel,Fire:Fire};})();</script><script data-ezscrex='false' data-cfasync='false' data-pagespeed-no-defer>__ez.pel=(function(){var pixels=[],pxURL="/porpoiseant/army.gif";function AddAndFirePixel(adSlot,pixelData){AddPixel(adSlot,pixelData,0,0,0,0,0);Fire();}
function AddAndFireOrigPixel(adSlot,pixelData){AddPixel(adSlot,pixelData,0,0,0,0,0,true);Fire();}
function GetCurrentPixels(){return pixels;}
function AddPixel(adSlot,pixelData,revenue,est_revenue,bid_floor_filled,bid_floor_prev,stat_source_id,isOrig){if(!__ez.dot.isDefined(adSlot)||__ez.dot.isAnyDefined(adSlot.getSlotElementId,adSlot.ElementId)==false){return;}
var ad_position_id=parseInt(__ez.dot.getTargeting(adSlot,'ap'));var impId=__ez.dot.getSlotIID(adSlot),adUnit=__ez.dot.getAdUnit(adSlot,isOrig);var compId=parseInt(__ez.dot.getTargeting(adSlot,"compid"));var lineItemId=0;var creativeId=0;var ezimData=getEzimData(adSlot);if(typeof ezimData=='object'){if(ezimData.creative_id!==undefined){creativeId=ezimData.creative_id;}
if(ezimData.line_item_id!==undefined){lineItemId=ezimData.line_item_id;}}
if(__ez.dot.isDefined(impId,adUnit)&&__ez.dot.isValid(pixelData)){pixels.push({type:"impression",impression_id:impId,domain_id:__ez.dot.getDID(),unit:adUnit,t_epoch:__ez.dot.getEpoch(0),revenue:revenue,est_revenue:est_revenue,ad_position:ad_position_id,ad_size:"",bid_floor_filled:bid_floor_filled,bid_floor_prev:bid_floor_prev,stat_source_id:stat_source_id,country_code:__ez.dot.getCC(),pageview_id:__ez.dot.getPageviewId(),comp_id:compId,line_item_id:lineItemId,creative_id:creativeId,data:__ez.dot.dataToStr(pixelData),is_orig:isOrig||__ez.template.isOrig,});}}
function AddPixelById(impFullId,pixelData,isOrig){var vals=impFullId.split('/');if(__ez.dot.isDefined(impFullId)&&vals.length===3&&__ez.dot.isValid(pixelData)){var adUnit=vals[0],impId=vals[2];pixels.push({type:"impression",impression_id:impId,domain_id:__ez.dot.getDID(),unit:adUnit,t_epoch:__ez.dot.getEpoch(0),pageview_id:__ez.dot.getPageviewId(),data:__ez.dot.dataToStr(pixelData),is_orig:isOrig||__ez.template.isOrig});}}
function Fire(){if(typeof document.visibilityState!=='undefined'&&document.visibilityState==="prerender")return;if(__ez.dot.isDefined(pixels)&&pixels.length>0){var allPixels=[pixels.filter(function(pixel){return pixel.is_orig}),pixels.filter(function(pixel){return!pixel.is_orig})];allPixels.forEach(function(pixels){while(pixels.length>0){var isOrig=pixels[0].is_orig||false;var j=5;if(j>pixels.length){j=pixels.length;}
var pushPixels=pixels.splice(0,j);var pixelURL=__ez.dot.getURL(pxURL)+"?orig="+(isOrig===true?1:0)+"&sts="+btoa(JSON.stringify(pushPixels));if(typeof window.isAmp!=='undefined'&&isAmp&&typeof window._ezaq!=='undefined'&&_ezaq.hasOwnProperty("domain_id")){pixelURL+="&visit_uuid="+_ezaq['visit_uuid'];}
__ez.dot.Fire(pixelURL);}})}
pixels=[];}
function getEzimData(adSlot){if(typeof _ezim_d=="undefined"){return false}
var adUnitName=__ez.dot.getAdUnitPath(adSlot).split('/').pop();if(typeof _ezim_d==='object'&&_ezim_d.hasOwnProperty(adUnitName)){return _ezim_d[adUnitName];}
for(var ezimKey in _ezim_d){if(ezimKey.split('/').pop()===adUnitName){return _ezim_d[ezimKey];}}
return false;}
return{Add:AddPixel,AddAndFire:AddAndFirePixel,AddAndFireOrig:AddAndFireOrigPixel,AddById:AddPixelById,Fire:Fire,GetPixels:GetCurrentPixels,};})();__ez.queue.addFile('/detroitchicago/raleigh.js', '/detroitchicago/raleigh.js?gcb=194-2&cb=5', false, [], true, false, true, false);__ez.queue.addFile('/detroitchicago/tampa.js', '/detroitchicago/tampa.js?gcb=194-2&cb=3', false, [], true, false, true, false);</script>
<script data-ezscrex="false" data-cfasync="false">(function(){if("function"===typeof window.CustomEvent)return!1;window.CustomEvent=function(c,a){a=a||{bubbles:!1,cancelable:!1,detail:null};var b=document.createEvent("CustomEvent");b.initCustomEvent(c,a.bubbles,a.cancelable,a.detail);return b}})();</script><script data-ezscrex="false" data-cfasync="false">__ez.queue.addFile('/detroitchicago/tulsa.js', '/detroitchicago/tulsa.js?gcb=194-2&cb=5', false, [], true, false, true, false);</script>
<title>Discounted Payback Period Calculator | Good Calculators</title>

<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="description" content="Use this handy Discounted Payback Period Calculator online to work out your discounted payback period"/>
<meta name="keywords" content="payback, discounted period, formula, rate, discounted payback, DPP, DCF, CCF, cash flow, cumulative discounted cash flow, present value, investment, discount rate, PV factor, discounted cash flow, cash inflow, calculator, calculation, online calculators"/>
<meta name="robots" content="all"/>

<meta name="MobileOptimized" content="width"/>
<meta name="HandheldFriendly" content="true"/>
<meta name="viewport" content="width=device-width"/>
<meta http-equiv="cleartype" content="on"/>

<link href="/css/style.css" type="text/css" rel="stylesheet"/>
<link href="/css/calcb.css" rel="stylesheet" type="text/css"/>
<link href="/css/base.css" rel="stylesheet" type="text/css"/>
<link href="/css/calculator.css" type="text/css" rel="stylesheet"/>
<link href="/css/social-likes_classic.css" type="text/css" rel="stylesheet"/>
<!--[if lt IE 9]>
<script src="/js/html5.js"></script>
<![endif]-->
<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript">
jQuery.noConflict();
</script>
<script type="text/javascript" src="/js/js.js"></script>
<link rel="shortcut icon" href="/i/favicon.ico" type="image/x-icon"/><script type="text/javascript">
jQuery(document).ready(function(n){n(".cats-mob").prepend('<div id="menu-button">Good Calculators</div>'),n(".cats-mob #menu-button").on("click",function(){var o=n(this).next("ul");o.hasClass("open")?o.removeClass("open"):o.addClass("open")})});
</script>
<script type="text/javascript" src="/js/calcmenu.js"></script>
<script async="" src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<link rel='canonical' href='https://goodcalculators.com/discounted-payback-period-calculator/' />
<script type="text/javascript">var ezouid = "1";</script><base href="https://goodcalculators.com/discounted-payback-period-calculator/"><script type='text/javascript'>
var ezoTemplate = 'old_site_gc

var ezoFormfactor = '1
var ezo_elements_to_check = Array();
</script><!-- START EZHEAD -->
<script data-ezscrex="false" type='text/javascript'>
var soc_app_id = '0
var did = 124911;
var ezdomain = 'goodcalculators.com
var ezoicSearchable = 1;
</script>
<!--{jquery}-->
<!-- END EZHEAD -->
<script data-ezscrex="false" type="text/javascript" data-cfasync="false">var _ezaq = {"ad_cache_level":0,"ad_lazyload_version":0,"ad_load_version":0,"city":"San Francisco","country":"US","days_since_last_visit":-1,"domain_id":124911,"engaged_time_visit":0,"ezcache_level":1,"ezcache_skip_code":11,"form_factor_id":1,"framework_id":1,"is_return_visitor":false,"is_sitespeed":0,"last_page_load":"","last_pageview_id":"","lt_cache_level":0,"metro_code":807,"page_ad_positions":"","page_view_count":0,"page_view_id":"7dd65b30-b7e7-4e42-5031-b2b4c8185714","position_selection_id":0,"postal_code":"94124","pv_event_count":0,"response_size_orig":100651,"response_time_orig":676,"serverid":"35.160.13.89:1321","state":"CA","t_epoch":1621246922,"template_id":126,"time_on_site_visit":0,"url":"https://goodcalculators.com/discounted-payback-period-calculator/","user_id":0,"word_count":2012,"worst_bad_word_level":0};var _ezExtraQueries = "&ez_orig=1";</script>
<script src="//www.ezojs.com/ezoic/ezd.js" defer async></script>
<script data-ezscrex='false' data-pagespeed-no-defer data-cfasync='false'>
function create_ezolpl(pvID, rv) {
var d = new Date();
d.setTime(d.getTime() + (365*24*60*60*1000));
var expires = "expires="+d.toUTCString();
__ez.ck.setByCat("ezux_lpl_124911=" + new Date().getTime() + "|" + pvID + "|" + rv + "; " + expires, 3);
}
function attach_ezolpl(pvID, rv) {
if (document.readyState === "complete") {
create_ezolpl(pvID, rv);
}
if(window.attachEvent) {
window.attachEvent("onload", create_ezolpl, pvID, rv);
} else {
if(window.onload) {
var curronload = window.onload;
var newonload = function(evt) {
curronload(evt);
create_ezolpl(pvID, rv);
};
window.onload = newonload;
} else {
window.onload = create_ezolpl.bind(null, pvID, rv);
}
}
}

__ez.queue.addFunc("attach_ezolpl", "attach_ezolpl", ["7dd65b30-b7e7-4e42-5031-b2b4c8185714", "false"], false, ['/detroitchicago/boise.js'], true, false, false, false);
</script></head>
<body class="html front sidebar-first">
<div id="fb-root"></div>
<div id="page-wrap">
<div id="page">
<style type="text/css">
#header-top-center {top:18px}
#header-top-right {top:20px}
</style>
<header id="header" style="padding-top:20px;padding-bottom:20px;" role="banner">

<a href="/" title="Good Calculators: Free Online Calculators" rel="home" id="logo"><img src="/i/logos.png" alt="Good Calculators: Free Online Calculators"/></a>

<hgroup id="name-with-type">
<span id="site-name">
<a href="/" title="Good Calculators: Free Online Calculators" rel="home"><span>GoodCalculators.com</span></a>
</span>

<span id="site-types"><span class="line-1">A collection of really good online calculators</span> <span class="line-2">for use in every day domestic and commercial use!</span></span>
</hgroup>

<hgroup id="header-top-center">
<div class="region region-header-top-center">
<div id="block-search-api-page-search" class="block block-search-api-page first last odd">

<form action="/search/" id="search-goodcalcs-page-search-form-search" accept-charset="UTF-8">
<div>
<div class="form-item form-type-textfield form-item-keys-1">
<input placeholder="Search" type="search" id="edit-keys-1" name="q" value="" size="15" maxlength="128" class="form-text"/>
</div>
<input type="submit" id="edit-submit-1" value="Search" class="form-submit"/>
</div>
</form>

</div>

</div>
</hgroup>

<hgroup id="header-top-right">
<div class="region region-header-top-right">
<div id="block-menu-menu-menu-header-right" class="block block-menu header-button first last odd" role="navigation">

<ul class="menu"><li class="menu__item is-leaf first leaf"><a href="/" title="Home page" class="menu__link home-link">Home page</a></li>
<li class="menu__item is-leaf last leaf"><a href="/contact/" title="Contact Us | About Us" class="menu__link mail-link">Contact</a></li>
</ul>
</div>
</div>
</hgroup>

<div class="clearfix"></div>

<div class="header__region region region-header">
<div id="block-block-18" class="block block-block first last odd">


<div class="cats-mob">
<ul>
<li><a href="/salary-income-tax-calculators/" class="section section-calc-types1">
<span class="section-ico"></span>
<span class="section-title">Salary &amp; Income Tax Calculators</span>
</a></li>
<li><a href="/mortgage-calculators/" class="section section-calc-types2">
<span class="section-ico"></span>
<span class="section-title">Mortgage Calculators</span>
</a></li>
<li><a href="/retirement-calculators/" class="section section-calc-types3">
<span class="section-ico"></span>
<span class="section-title">Retirement Calculators</span>
</a></li>
<li><a href="/depreciation-calculators/" class="section section-calc-types4 margin-right">
<span class="section-ico"></span>
<span class="section-title">Depreciation Calculators</span>
</a></li>
<li><a href="/statistics-calculators/" class="section section-calc-types5 clear-left">
<span class="section-ico"></span>
<span class="section-title">Statistics and Analysis Calculators</span>
</a></li>
<li><a href="/date-time-calculators/" class="section section-calc-types6">
<span class="section-ico"></span>
<span class="section-title">Date and Time Calculators</span>
</a></li>
<li><a href="/contractor-calculators/" class="section section-calc-types7">
<span class="section-ico"></span>
<span class="section-title">Contractor Calculators</span>
</a></li>
<li><a href="/budget-calculators/" class="section section-calc-types8 margin-right">
<span class="section-ico"></span>
<span class="section-title">Budget &amp; Savings Calculators</span>
</a></li>
<li><a href="/loan-calculators/" class="section section-calc-types9  clear-left">
<span class="section-ico"></span>
<span class="section-title">Loan Calculators</span>
</a></li>
<li><a href="/forex-calculators/" class="section section-calc-types10">
<span class="section-ico"></span>
<span class="section-title">Forex Calculators</span>
</a></li>
<li><a href="/real-function-calculators/" class="section section-calc-types11">
<span class="section-ico"></span>
<span class="section-title">Real Function Calculators</span>
</a></li>
<li><a href="/engineering-calculators/" class="section section-calc-types12 margin-right">
<span class="section-ico"></span>
<span class="section-title">Engineering Calculators</span>
</a></li>

<li><a href="/tax-calculators/" class="section section-calc-conversion">
<span class="section-ico"></span>
<span class="section-title">Tax Calculators</span>
</a></li>
<li><a href="/volume-calculators/" class="section section-calc-ratio">
<span class="section-ico"></span>
<span class="section-title">Volume Calculators</span>
</a></li>
<li><a href="/2d-shape-calculators/" class="section section-calc-volume">
<span class="section-ico"></span>
<span class="section-title">2D Shape Calculators</span>
</a></li>
<li><a href="/3d-shape-calculators/" class="section section-calc-2dshape margin-right">
<span class="section-ico"></span>
<span class="section-title">3D Shape Calculators</span>
</a></li>
<li><a href="/logistics-calculators/" class="section section-calc-3dshape clear-left">
<span class="section-ico"></span>
<span class="section-title">Logistics Calculators</span>
</a></li>
<li><a href="/hrm-calculators/" class="section section-calc-realfunction">
<span class="section-ico"></span>
<span class="section-title">HRM Calculators</span>
</a></li>
<li><a href="/sales-investments-calculators/" class="section section-calc-statistics">
<span class="section-ico"></span>
<span class="section-title">Sales &amp; Investments Calculators</span>
</a></li>
<li><a href="/grade-gpa-calculators/" class="section section-calc-datetime margin-right">
<span class="section-ico"></span>
<span class="section-title">Grade &amp; GPA Calculators</span>
</a></li>
<li><a href="/conversion-calculators/" class="section section-calc-logistics clear-left">
<span class="section-ico"></span>
<span class="section-title">Conversion Calculators</span>
</a></li>
<li><a href="/ratio-calculators/" class="section section-calc-engineering">
<span class="section-ico"></span>
<span class="section-title">Ratio Calculators</span>
</a></li>
<li><a href="/sports-health-calculators/" class="section section-calc-sports">
<span class="section-ico"></span>
<span class="section-title">Sports &amp; Health Calculators</span>
</a></li>
<li><a href="/other-calculators/" class="section section-calc-grade margin-right">
<span class="section-ico"></span>
<span class="section-title">Other Calculators</span>
</a></li>
</ul>

</div>
</div>
</div>
<div class="clearfix"></div>

<div class="header-bg"></div>
</header>

<div id="main">

<div id="content" class="column" role="main" style="background-color:#ffffff;">	<div class="breadcrumbs"><a href="/">Home</a> » <a href="/sales-investments-calculators/">Sales and Investments Calculators</a> » Discounted Payback Period Calculator</div>
<div style="margin-bottom:0px;padding:0px;padding-top:4px;padding-left:0px;background-color:#FFFFFF;">
<script src="/js/char.js"></script>
<link rel="stylesheet" type="text/css" href="/css/calcplus.css"/>
<style type="text/css">
.goodCalculator {padding: 0;}
table.GoodResults td input[type=text], table.GoodResults td input[type=number] {width: 5em;}
.Begin .contact label {min-width: 190px;}
.resultBlock {border:1px solid #ccc;padding:20px;margin-top:10px;background:#ffffff;}
.bolder {font-weight: 600;font-size: 1em;color: red;}
.notes {background-color: #fffcdb;border: 1px solid #ccc;padding: 10px;margin-top: 10px;}
.notes i {display: block;width: 35px;float: left;}
.hidden {display: none;}
.Begin input[disabled="disabled"] {opacity: 0.75 !important;}
#appcfblock{background-color:#fafafa;}
@media (max-width: 680px){
.notes, .notes div{font-size: .87em;font-weight: 400;}}
@media ( max-width: 500px){
.Begin .contact label {min-width: 140px;}
}
</style>
<div class="goodcalctrs">
<h1>Discounted Payback Period Calculator</h1>

<div class="article">
<p>
Discounted payback is something that investors use. It is a useful way to work out how long it takes to get your capital back from the cash flows.
It shows the number of years you will need to get that money back based on present returns. Each present value cash flow is calculated and then added together.
The result is the discounted payback period or DPP. Our calculator uses the time value of money so you can see how well an investment is performing.
</p>
<p>The calculator below helps you calculate the discounted payback period based on the amount you initially invest, the discount rate, and the number of years.</p>
<p>We have made it easy for you to use and get the right DPP figures:</p>
<ul>
<li>Choose your currency from the list (this step is optional)</li>
<li>Key in the amount of your investment</li>
<li>Put in the discount rate and the years of cash flow</li>
<li>The last step is to input the annual cash flow for each year</li>
<li>Then click &#34;Calculate&#34; to see the answer.</li>
</ul>
</div>

<div align="center" class="Begin" id="adsg19" style="padding-top:0px;max-width:840px;padding-bottom:15px;width:100%">
<!-- Ezoic - middle unit  - mid_content -->
<div id="ezoic-pub-ad-placeholder-103">
<!-- ads_lnk -->
<ins class="adsbygoogle" style="display: block" data-ad-client="ca-pub-8769099798826667" data-ad-slot="4135302666" data-ad-format="horizontal"></ins>
</div>
<!-- End Ezoic - middle unit  - mid_content -->
</div>
<div class="Begin goodCalculator" style="padding-bottom:0px;padding-top:0px;">
<fieldset>
<legend title="DPP Calculator">Discounted Payback Period (DPP) Calculator</legend>
<form class="contact" id="dppcalc">
<input type="hidden" id="gcsdiffb" name="csipts" value="odd"/>
<p>
<label for="currency">Currency (optional):</label>
<select id="currency" name="currency" onchange="DPPCalc()">
<option selected="selected">$ (dollar)</option>
<option>£ (pound sterling)</option>
<option>€ (euro)</option>
<option>¥ (yen)</option>
<option>none</option>
</select>
</p>
<p>
<label for="initCost">Initial Investment (<span id="cur1">$</span>):</label>
<input type="number" min="0" name="initCost" value="10000" id="invst0" onchange=""/>
</p>
<p>
<label for="discountRate">Discount Rate, % :</label>
<input type="number" min="0" name="discountRate" value="10" id="discountRate" onchange=""/>
</p>
<p>
<label for="years">Number of Years:</label>
<input type="number" min="1" name="years" value="1" id="years" onchange="addbox(this);"/>
</p>
<div id="appcfblock">
<p><label><b>Year:</b></label><b>Annual Cash Flow:</b></p>
<p><label for="invst1">Year 1</label><input type="number" value="5000" id="invst1"/></p>
</div>
<p>
<input type="button" value="Calculate" class="submit" onclick="DPPCalc();"/>
<input type="button" value="Reset" class="submit" onclick="Clear()"/>
</p>
</form>
</fieldset>
<div class="resultBlock hidden">
<div class="imgst" style="font-size:16px; font-weight:bold; height:40px; color: #444444;">Results</div>
<div id="calcres" style="font-size: 1.2em;"></div>
<div id="calcres1" style="font-size: 1.2em;"></div>
<table id="GoodResults" class="GoodResults" style="width:100%;"></table>
<div class="notes hidden">
<h4 style="margin-top:0.25em;">Notes</h4>
<div style="margin-top:1em;"><i>CF</i> Cash Flow</div>
<div style="margin-top:1em;"><i>NCF</i> Net Cash Flow</div>
<div style="margin-top:0.6em;"><i style="margin-top: 0.3em">PV</i> Present Value Factor, PV<span id="curnt1">$</span>1 = 1/(1+i)<sup>n</sup></div>
<div style="margin-top:1em;"><i>DCF</i> Discounted Cash Flow, CF × PV<span id="curnt2">$</span>1</div>
<div style="margin-top:1em;"><i>CCF</i> Cumulative Discounted Cash Flow</div>
</div>
</div>
</div>
<div align="center" class="Begin" id="adsg16" style="padding-top:0px;padding-bottom:15px;">
<!-- Ezoic - bottom  - bottom_of_page -->
<div id="ezoic-pub-ad-placeholder-105">
<!-- ads_1 -->
<ins class="adsbygoogle" style="display: block" data-ad-client="ca-pub-8769099798826667" data-ad-slot="4135302666" data-ad-format="horizontal"></ins>
</div>
<!-- End Ezoic - bottom  - bottom_of_page -->
</div>

<div class="article">
<h2>The Discounted Payback Period (DPP) Formula and a Sample Calculation</h2>
<p>We use two other figures in this calculation – the PV or Present Value and the CF or Cash Flow.
We begin from the first year as the starting point.</p>
<p>You need to specify a set discount rate for the calculation. This can be worked out in the following way:</p>
<ul>
<li><strong>Discounted Cash Flow (or DCF) is the Actual Cash Inflow / [1 + i]^n</strong></li>
<li>Where,</li>
<li><b>i</b> - denotes the discount rate used,</li>
<li><b>n</b> - denotes the time period relating to the cash inflows.</li>
</ul>
<p>So, the two parts of the calculation (the cash flow and PV factor) are shown above.
We can conclude from this that the DCF is the calculation of the PV factor and the actual cash inflow.</p>
<ul>
<li><strong>The Discounted Payback Period (or DPP) is X + Y/Z</strong></li>
<li>In this calculation: </li>
<li><b>X</b> is the last time period where the cumulative discounted cash flow (CCF) was negative,</li>
<li><b>Y</b> is the absolute value of the CCF at the end of that period X,</li>
<li><b>Z</b> is the value of the DCF in the next period after X.</li>
</ul>
<p>The DPP method can be seen in the example set out here –</p>
<p>Initially an investment of $100,000 can be expected to make an income of $35k per annum for 4 years.
If the discount rate is 10% then we can calculate the DPP.</p>
<p style="padding-bottom:1.5em;"><b>Step 1:</b> The DCF for each period is calculated as follows - we multiply the actual cash flows with the PV factor. From that we can derive the discounted cash flows on a cumulative basis.</p>
<div>
<table class="GoodResults" style="width: 100%; display: table;">
<tbody><tr>
<th>Year (n)</th>
<th>Cash Flow (CF)</th>
<th>Net Cash Flow (NCF)</th>
<th>PV Factor <br/>PV= 1/(1+i)<sup>n</sup></th>
<th>Discounted Cash Flow <br/>DCF = CF x PV</th>
<th>Cumulative Discounted Cash Flow <br/>(CCF)</th>
</tr>
<tr class="odd"><td>0</td><td>-100000</td><td>-100000</td><td>1</td><td>-100000</td><td>-100000</td></tr>
<tr><td>1</td><td>35000</td><td>-65000</td><td>0.91</td><td>31818.18</td><td>-68181.82</td></tr>
<tr class="odd"><td>2</td><td>35000</td><td>-30000</td><td>0.83</td><td>28925.62</td><td>-39256.2</td></tr>
<tr><td><span style="padding:2px;border:1px dashed red;background:#fffcdb">3</span></td><td>35000</td><td>5000</td><td>0.75</td><td>26296.02</td><td><span style="padding:2px;border:1px dashed red;background:#fffcdb">-12960.18</span></td></tr>
<tr class="odd"><td>4</td><td>35000</td><td>40000</td><td>0.68</td><td><span style="padding:2px;border:1px dashed red;background:#fffcdb">23905.47</span></td><td>10945.29</td></tr>
</tbody></table></div>

<p style="padding-top:1.5em;"><b>Step 2:</b> The DPP is X + Y/Z = 3 + |-12,960.18| / 23,905.47 ≈ 3.54 years</p>
<p>The Discounted Payback Period is 3.54 years.</p>
</div>

</div>
</div>

<script src="/js/social-likes.min.js"></script><div id="id-social-buttons" class="social-likes"><div class="facebook" title="Share link on Facebook">Facebook</div><div class="twitter" title="Share link on Twitter">Twitter</div></div><div class="ratedop"><style type="text/css">
.ratingblock {
display:block;
padding-bottom:8px;
margin-bottom:8px;
}

.loading {
height: 30px;
background: url('/rating/images/working.gif') 50% 50% no-repeat;
}

.unit-rating { /* the UL */
list-style:none;
margin: 0px;
padding:0px;
height: 25px;
min-height: 25px;
position: relative;
background: url('/rating/images/alt_star8.gif') top left repeat-x;
}

.unit-rating li{
text-indent: -90000px;
padding:0px;
margin:0px;
/*\*/
float: left;
/* */
}

.unit-rating li a {
outline: none;
display:block;
width: 25px;
height: 25px;
min-height: 25px;
text-decoration: none;
text-indent: -9000px;
z-index: 20;
position: absolute;
padding: 0px;
}

.unit-rating li a:hover{
background: url('/rating/images/alt_star8.gif') left center;
z-index: 2;
left: 0px;
}

.unit-rating a.r1-unit{left: 0px;}
.unit-rating a.r1-unit:hover{width:25px;}
.unit-rating a.r2-unit{left:25px;}
.unit-rating a.r2-unit:hover{width: 50px;}
.unit-rating a.r3-unit{left: 50px;}
.unit-rating a.r3-unit:hover{width: 75px;}
.unit-rating a.r4-unit{left: 75px;}
.unit-rating a.r4-unit:hover{width: 100px;}
.unit-rating a.r5-unit{left: 100px;}
.unit-rating a.r5-unit:hover{width: 125px;}
.unit-rating a.r6-unit{left: 125px;}
.unit-rating a.r6-unit:hover{width: 150px;}
.unit-rating a.r7-unit{left: 150px;}
.unit-rating a.r7-unit:hover{width: 175px;}
.unit-rating a.r8-unit{left: 175px;}
.unit-rating a.r8-unit:hover{width: 200px;}
.unit-rating a.r9-unit{left: 200px;}
.unit-rating a.r9-unit:hover{width: 225px;}
.unit-rating a.r10-unit{left: 225px;}
.unit-rating a.r10-unit:hover{width: 250px;}

.unit-rating li.current-rating {
background: url('/rating/images/alt_star8.gif') left bottom;
position: absolute;
height: 25px;
min-height: 25px;
display: block;
text-indent: -9000px;
z-index: 0;
}

.voted {color:#999;}
.thanks {color:#b11116;}
.static {color:#6A920F;}
</style><script type="text/javascript" language="javascript" src="/rating/behavior.js"></script>
<script type="text/javascript" language="javascript" src="/rating/rating.js.php"></script>
<div id="container89954"><div class="ratingblock"><div id="unit_long/discounted-payback-period-calculator/">  <ul id="unit_ul/discounted-payback-period-calculator/" class="unit-rating" style="width:125px;">     <li class="current-rating" style="width:104px;">Currently 4.17/5</li><li><a href="/rating/db.php?j=1&amp;q=/discounted-payback-period-calculator/&amp;t=192.241.198.127&amp;c=5" title="1 of 5" class="r1-unit rater" rel="nofollow">1</a></li><li><a href="/rating/db.php?j=2&amp;q=/discounted-payback-period-calculator/&amp;t=192.241.198.127&amp;c=5" title="2 of 5" class="r2-unit rater" rel="nofollow">2</a></li><li><a href="/rating/db.php?j=3&amp;q=/discounted-payback-period-calculator/&amp;t=192.241.198.127&amp;c=5" title="3 of 5" class="r3-unit rater" rel="nofollow">3</a></li><li><a href="/rating/db.php?j=4&amp;q=/discounted-payback-period-calculator/&amp;t=192.241.198.127&amp;c=5" title="4 of 5" class="r4-unit rater" rel="nofollow">4</a></li><li><a href="/rating/db.php?j=5&amp;q=/discounted-payback-period-calculator/&amp;t=192.241.198.127&amp;c=5" title="5 of 5" class="r5-unit rater" rel="nofollow">5</a></li>  </ul>  <p style="padding:4px 0px;"> Rating: <strong> 4.2</strong>/5 (155 votes)  </p></div></div></div></div>
<script src="/js/jquery.min.js"></script>
<script type="text/javascript">
function DPPCalc(){var e="";e=document.getElementById("currency");var t=e.value;t=t.toString().charAt(0),"n"===t&&(t=""),e=document.getElementById("cur1"),e.innerHTML=t,document.getElementById("curnt1").innerHTML=t,document.getElementById("curnt2").innerHTML=t,$("#GoodResults tr").remove(),document.getElementById("calcres").innerHTML="",document.getElementById("calcres1").innerHTML="";var d=document.getElementById("years").value,a=document.getElementById("discountRate").value,n=document.getElementById("invst0").value,r=a/100,s=[],l=0,o=0,c=[],u=0;if(""==a)return alert("Please enter the Discount Rate"),!1;if(""==n)return alert("Please enter the Initial Investment"),!1;if("null"==d)return alert("Please enter the Number of Years"),!1;for(i=1;d>=i;i++)if(cash=document.getElementById("invst"+i).value,fel=document.getElementById("invst1").value,""==fel&&alert("Please enter at least one year of Cash Flow"),""==cash||0==cash)u++;else{$("#GoodResults").append('<tr id="ils"><th colspan="6">Discounted Payback Period Calculator &ndash; Results</th></tr><tr id="HeaderRow"><th>Year</th><th>CF</th><th>NCF</th><th>PV Factor</th><th>DCF</th><th>CCF</th></tr>');var i=0;n>0&&(n=-n),o=n/Math.pow(1+r,0),c[0]=o,tmpz=1/Math.pow(1+r,0);var h=$("#gcsdiffb").val();"odd"==h?$("#gcsdiffb").val("even"):$("#gcsdiffb").val("odd"),$("#GoodResults").append('<tr class="TRactive '+h+'"><td>'+i+"</td><td>"+t+c3(n)+"</td><td>"+t+c3(n)+"</td><td>"+Math.round(100*tmpz)/100+"</td><td>"+t+c3(Math.round(100*o)/100)+"</td><td>"+t+c3(Math.round(100*c[0])/100)+"</td></tr>");var p,m=0,f=n;for(i=1;d>=i;i++){cash=document.getElementById("invst"+i).value,f=1*f+1*cash,s[i]=cash/Math.pow(1+r,i),tmpz=1/Math.pow(1+r,i),c[i]=c[i-1]+s[i];var h=$("#gcsdiffb").val();"odd"==h?$("#gcsdiffb").val("even"):$("#gcsdiffb").val("odd"),m=Math.round(100*s[i])/100+m,$("#GoodResults").append('<tr class="TRactive '+h+"\"><td><span id='ex"+i+"' style=''>"+i+"</span></td><td>"+t+c3(cash)+"</td><td>"+t+c3(Math.round(100*f)/100)+"</td><td>"+Math.round(100*tmpz)/100+"</td><td><span id='expl"+i+"' style=''>"+t+c3(Math.round(100*s[i])/100)+"</span></td><td><span id='exp"+(i+1)+"' style=''>"+t+c3(Math.round(100*c[i])/100)+"</span></td></tr>"),c[i]>=0&&c[i-1]<0&&(l=i-1+Math.abs(c[i-1])/(c[i]+Math.abs(c[i-1])),document.getElementById("calcres").innerHTML="<br />Discounted Payback Period: <span style='color:red; font-weight:bold;'>"+Math.round(100*l)/100+"</span> years. <br />Discounted Payback Period = X + Y/Z = "+(i-1)+" + |"+Math.round(100*c[i-1])/100+"| / "+Math.round(100*(c[i]+Math.abs(c[i-1])))/100+" &asymp; "+Math.round(100*l)/100+" years. <br />",$("#ex"+(i-1)).css({padding:"2px",border:"1px dashed red",background:"#fffcdb"}),$("#exp"+i).css({padding:"2px",border:"1px dashed red",background:"#fffcdb"}),$("#expl"+i).css({padding:"2px",border:"1px dashed red",background:"#fffcdb"}))}p=m/(i-1),resultBlock.removeClass(hiddenClass),notes.removeClass(hiddenClass),$("#GoodResults").show(),null==$("#calcres").get(0).firstChild&&(document.getElementById("calcres1").innerHTML="<br />With the current discount rate of "+a+"%, the Investment won't pay back in "+(1*i-1)+" years. <br /> The average discounted payback is "+t+c3(Math.round(100*p)/100)+"/year in the first "+(1*i-1)+" years. <br />")}}function c3(e){return tmp=e,""+tmp.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g,"$1,")}function addbox(e){var t=e.value;if(t=parseFloat(t),$("#appcfblock").html(""),!isNaN(t)){if(t>50||0>=t)return alert("Please provide a positive number of years that is 50 or less"),0;for(var d="<p><label><b>Year:</b></label><b>Annual Cash Flow:</b></p>",a=1;t>=a;a++)d+="<p><label for=invst"+a+">Year "+a+"</label><input type='number' id=invst"+a+"></p>";d+="",$("#appcfblock").html(d)}}function Clear(){document.getElementById("dppcalc").reset(),$("#GoodResults tr").remove(),$("#GoodResults").hide(),$("#gcsdiffb").val("odd"),$("#years").val("1"),$("#appcfblock p:gt(1)").remove(),$("#invst1").val("5000"),document.getElementById("calcres").innerHTML="",document.getElementById("calcres1").innerHTML="",resultBlock.addClass(hiddenClass),notes.addClass(hiddenClass),document.getElementById("cur1").innerHTML="&#36;"}var hiddenClass="hidden",notes=$(".notes"),resultBlock=$(".resultBlock");jQuery(document).ready(function(e){e("#GoodResults").hide()});
</script>
</div><aside class="sidebars">
<section class="region region-sidebar-first column sidebar">

<div style="background-color: #FFFFFF;width:300px;height:auto;margin:0 0 10px;padding:0px;">
<div class="bestcalcblock">Top 10 Best Calculators</div>
<div style="height:auto;background-color:#FFFFFF;">
<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/us-salary-tax-calculator/" title="United States Income Tax Calculator" style="text-decoration:none; font-size: 14px;">United States Income Tax Calculator</a>
</div></div>

<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/eic-calculator/" title="EIC (Earned Income Credit) Calculator" style="text-decoration:none; font-size: 14px;">Earned Income Credit Calculator</a>
</div></div>

<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/irs-interest-calculator/" title="IRS Interest Calculator" style="text-decoration:none; font-size: 14px;">IRS Interest Calculator</a>
</div></div>

<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/car-depreciation-calculator/" title="Car Depreciation Calculator" style="text-decoration:none; font-size: 14px;">Car Depreciation Calculator</a>
<span style="font-size:0.8em;color:red;font-style:italic;"> new</span>
</div></div>

<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/va-disability-calculator/" title="VA Disability Calculator" style="text-decoration:none; font-size: 14px;">VA Disability Calculator</a>
</div></div>

<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/water-intake-calculator/" title="Water Intake Calculator" style="text-decoration:none; font-size: 14px;">Water Intake Calculator</a>
<span style="font-size:0.8em;color:red;font-style:italic;"> new</span>
</div></div>

<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/pay-raise-calculator/" title="Pay Raise Calculator" style="text-decoration:none; font-size: 14px;">Pay Raise Calculator</a>
</div></div>

<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/stock-calculator/" title="Stock Calculator" style="text-decoration:none; font-size: 14px;">Stock Calculator</a>
</div></div>

<div><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/ratio-calculator/" title="Ratio Calculator | Calculate Equivalent Ratios" style="text-decoration:none; font-size: 14px;">Ratio Calculator</a>
</div></div>

<div style="padding-bottom:15px"><div class="artcnt" style="text-decoration:none; font-size: 14px;">
<div style="margin-right:5px; float:left; width:15px; height:16px;"></div>
<a href="/apft-calculator/" title="APFT (Army Physical Fitness Test) Calculator" style="text-decoration:none; font-size: 14px;">APFT Calculator</a>
</div></div>

</div></div>


<div align="center" class="Begin" id="adsg3" style="width:300px;padding-top:0px;padding-bottom:0px;margin-bottom:10px">
<!-- Ezoic - sidebar ad  - sidebar -->
<div id="ezoic-pub-ad-placeholder-102">
<!-- ads_1 -->
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-8769099798826667" data-ad-slot="4135302666" data-ad-format="rectangle,vertical"></ins>
</div>
<!-- End Ezoic - sidebar ad  - sidebar -->
</div>


<div id="block-menu-menu-2" class="block block-menu block-calc block-calc-ctr3 first odd" role="navigation">

<h2 class="block__title block-title">Salary &amp; Income Tax Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/us-salary-tax-calculator/" class="menu__link" title="United States Salary Tax Calculator 2020/21">United States Salary Tax Calculator 2020/21</a></li>
<li class="menu__item is-leaf leaf"><a href="/us-minimum-wage-calculator/" class="menu__link" title="United States Minimum Wage Calculator 2021">United States Minimum Wage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/us-tax-brackets-calculator/" class="menu__link" title="United States (US) Tax Brackets Calculator">United States (US) Tax Brackets Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/tax-calculator/" class="menu__link" title="2020 - 2021 Tax and NI calculator UK">UK Tax &amp; NI Calculator 2020/21</a></li>
<li class="menu__item is-leaf leaf"><a href="/tax-calculator-2019/" class="menu__link" title="2019 - 2020 Tax and NI calculator UK">UK Tax &amp; NI Calculator 2019/20</a></li>
<li class="menu__item is-leaf leaf"><a href="/salary-sacrifice-calculator/" class="menu__link" title="Salary Sacrifice Calculator 2020/2021">Salary Sacrifice Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/corporation-tax-calculator/" class="menu__link" title="Corporation Tax Calculator 2020/21">Corporation Tax Calculator 2020/21</a></li>
<li class="menu__item is-leaf leaf"><a href="/dividend-tax-calculator/" class="menu__link" title="2020 - 2021 Dividend Tax Calculator &amp; Dividend Tax Calculator Widget for Your Website">Dividend Tax Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/dividends-calculator/" class="menu__link" title="Dividends Calculator 2020/21">Dividends Calculator 2020/21</a></li>
<li class="menu__item is-leaf leaf"><a href="/capital-gains-tax-calculator/" class="menu__link" title="Capital Gains Tax Calculator 2020/21">Capital Gains Tax Calculator 2020/21</a></li>
<li class="menu__item is-leaf leaf"><a href="/irs-interest-calculator/" class="menu__link" title="IRS Interest Calculator">IRS Interest Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/annual-salary-calculator/" class="menu__link" title="Hourly Wage to Annual Salary Conversion Calculator">Wage Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pay-raise-calculator/" class="menu__link" title="Pay Raise Calculator">Pay Raise Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/wage-garnishment-calculator/" class="menu__link" title="Wage Garnishment Calculator">Wage Garnishment Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/eic-calculator/" class="menu__link" title="Earned Income Credit (EIC) Calculator">EIC Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/salary-calculator/" class="menu__link" title="US Salary Calculator">Salary Calculator</a></li>

</ul>
</div>

<div id="block-menu-menu-1-calculator" class="block block-menu block-calc block-calc-ctr2 even" role="navigation">

<h2 class="block__title block-title">Retirement Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/401k-calculator/" class="menu__link" title="401k Calculator">401(k) Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/state-pension-age-calculator/" class="menu__link" title="State Pension Age Calculator">State Pension Age Calculator</a></li>

</ul>
</div>
<div id="block-menu-menu-calculator-menu" class="block block-menu block-calc block-calc-ctr1 odd" role="navigation">

<h2 class="block__title block-title">Mortgage Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/mortgage-calculator/" class="menu__link" title="Mortgage Calculator">Mortgage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/piti-mortgage-payment-calculator/" class="menu__link" title="PITI Mortgage Payment Calculator">PITI Mortgage Payment Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/mortgage-how-much-borrow/" class="menu__link" title="How Much can I borrow | Mortgage Calculator">How much can I borrow?</a></li>
<li class="menu__item is-leaf leaf"><a href="/mortgage-overpayment-calculator/" class="menu__link" title="Mortgage Overpayment Calculator">Mortgage Overpayment Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/piggyback-loan-calculator/" class="menu__link" title="Piggyback Loan Calculator">Piggyback Loan Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/balloon-mortgage-calculator/" class="menu__link" title="Balloon Mortgage Calculator">Balloon Mortgage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/graduated-payment-mortgage-calculator/" class="menu__link" title="Graduated Payment Mortgage (GPM) Calculator">Graduated Payment Mortgage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/mortgage-comparison-calculator/" class="menu__link" title="Mortgage Comparison Calculator">Mortgage Comparison Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/home-down-payment-calculator/" class="menu__link" title="Home Down Payment Calculator">Home Down Payment Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/mortgage-early-repayment-calculator/" class="menu__link" title="Mortgage Early Repayment Calculator">Mortgage Early Repayment Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/mortgage-points-calculator/" class="menu__link" title="Mortgage Points Calculator">Mortgage Points Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/escrow-calculator/" class="menu__link" title="Escrow Calculator">Escrow Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ltv-loan-to-value-calculator/" class="menu__link" title="LTV (Loan to Value) Calculator">Loan to Value (LTV) Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/heloc-payment-calculator/" class="menu__link" title="HELOC (Home Equity Line of Credit) Payment Calculator">HELOC Payment Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-3-calculators" class="block block-menu block-calc block-calc-ctr4 even" role="navigation">

<h2 class="block__title block-title">Depreciation Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/car-depreciation-calculator/" class="menu__link" title="Car Depreciation Calculator">Car Depreciation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/macrs-depreciation-calculator/" class="menu__link" title="MACRS (Modified Accelerated Cost Recovery System) Depreciation Calculator">MACRS Depreciation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/annuity-depreciation-calculator/" class="menu__link" title="Annuity Depreciation Calculator">Annuity Depreciation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/depreciation-comparison-calculator/" class="menu__link" title="Depreciation Comparison Calculator">Depreciation Comparison Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/percentage-depreciation-calculator/" class="menu__link" title="Percentage Depreciation Calculator">Percentage Depreciation Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/straight-line-depreciation-calculator/" class="menu__link" title="Straight Line Depreciation Calculator">Straight Line Depreciation Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-4-calculator" class="block block-menu block-calc block-calc-ctr5 odd" role="navigation">

<h2 class="block__title block-title">Statistics and Analysis Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/statistics-calculator-graph-generator/" class="menu__link" title="Statistics Calculator and Graph Generator">Statistics Calculator and Graph Generator</a></li>
<li class="menu__item is-leaf leaf"><a href="/standard-deviation-calculator/" class="menu__link" title="Standard Deviation Calculator">Standard Deviation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/arithmetic-geometric-mean-calculator/" class="menu__link" title="Arithmetic-Geometric Mean (AGM) Calculator">Arithmetic-Geometric Mean Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/interquartile-range-calculator/" class="menu__link" title="Interquartile Range (IQR) Calculator">Interquartile Range Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/midrange-calculator/" class="menu__link" title="Midrange Calculator">Midrange Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/percentile-calculator/" class="menu__link" title="Percentile Calculator">Percentile Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/empirical-rule-calculator/" class="menu__link" title="Empirical Rule Calculator">Empirical Rule Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/relative-risk-calculator/" class="menu__link" title="Relative Risk Calculator">Relative Risk Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/seir-model-calculator/" class="menu__link" title="SEIR Model Calculator">SEIR Model Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/linear-regression-calculator/" class="menu__link" title="Linear Regression Calculator">Linear Regression Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/quadratic-regression-calculator/" class="menu__link" title="Quadratic Regression Calculator">Quadratic Regression Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/best-fit-circle-least-squares-calculator/" class="menu__link" title="Least-Squares Circle Calculator">Least-Squares Circle Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rational-function-regression-calculator/" class="menu__link" title="Rational Function Regression Calculator">Rational Function Regression Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/expected-value-calculator/" class="menu__link" title="Expected Value (EV) Calculator">Expected Value Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/one-way-anova-calculator/" class="menu__link" title="ANOVA (Analysis Of Variance) Calculator | One-Way ANOVA Calculator">One-Way ANOVA Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/z-score-calculator/" class="menu__link" title="Z-Score Calculator">Z-Score Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/p-value-calculator/" class="menu__link" title="P-Value Calculator: Calculate P-value from Z-score">P-Value Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/student-t-value-calculator/" class="menu__link" title="Student T-Value Calculator">T-Value Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/chi-square-calculator/" class="menu__link" title="Chi-Square Calculator">Chi-Square Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/sample-size-calculator/" class="menu__link" title="Sample Size Calculator">Sample Size Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/effect-size-calculator/" class="menu__link" title="Effect Size (Cohen&#39;s d) Calculator">Effect Size Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/margin-of-error-calculator/" class="menu__link" title="Margin of Error (MOE) Calculator">Margin of Error Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/standard-error-calculator/" class="menu__link" title="Standard Error Calculator">Standard Error Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/percent-error-calculator/" class="menu__link" title="Percent Error Calculator">Percent Error Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/advanced-statistics-calculator/" class="menu__link" title="Advanced Statistics calculator">Advanced Statistics Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/probability-calculator/" class="menu__link" title="Probability Calculator">Probability Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/combinations-permutations-calculator/" class="menu__link" title="Combinations and Permutations Calculator">Combinations &amp; Permutations Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/gini-coefficient-calculator/" class="menu__link" title="Gini Coefficient Calculator">Gini Coefficient Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pert-calculator/" class="menu__link" title="PERT Analysis Calculator">PERT Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/six-sigma-calculator/" class="menu__link" title="Six Sigma (6 σ) Calculator">Six Sigma Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/point-estimate-calculator/" class="menu__link" title="Point Estimate Calculator">Point Estimate Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/black-scholes-calculator/" class="menu__link" title="Black Scholes Calculator">Black Scholes Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/historical-volatility-calculator/" class="menu__link" title="Historical Volatility (HV) Calculator">Historical Volatility Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/simple-moving-average-calculator/" class="menu__link" title="Simple Moving Average (SMA) Calculator">Simple Moving Average Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/exponential-moving-average-calculator/" class="menu__link" title="Exponential Moving Average (EMA) Calculator">Exponential Moving Average Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/weighted-moving-average-calculator/" class="menu__link" title="Weighted Moving Average (WMA) Calculator">Weighted Moving Average Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/grouped-frequency-distribution-calculator/" class="menu__link" title="Grouped Frequency Distribution Calculator">Grouped Frequency Distribution Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/box-plot-maker/" class="menu__link" title="Box-and-Whisker Plot Maker">Box Plot Maker</a></li>
<li class="menu__item is-leaf leaf"><a href="/pie-chart-calculator/" class="menu__link" title="Pie Chart Calculator | Pie Chart Maker">Pie Chart Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/random-number-generator/" class="menu__link" title="Random Number Generator">Random Number Generator</a></li>
<li class="menu__item is-leaf leaf"><a href="/normal-distribution-generator/" class="menu__link" title="Normal Distribution Generator">Normal Distribution Generator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/lottery-number-generator/" class="menu__link" title="Lottery Number Generator">Lottery Number Generator</a></li>
</ul>
</div>
<div id="block-menu-menu-5" class="block block-menu block-calc block-calc-ctr6 even" role="navigation">

<h2 class="block__title block-title">Date and Time Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/days-calculator-converter/" class="menu__link" title="Days Calculator - Converter">Days Calculator - Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/time-converter/" class="menu__link" title="Time Converter">Time Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/timesheet-calculator/" class="menu__link" title="Timesheet Calculator">Timesheet Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/age-calculator/" class="menu__link" title="Age Calculator">Age Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/dog-age-calculator/" class="menu__link" title="Dog Age Calculator">Dog Age Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/tree-age-calculator/" class="menu__link" title="Tree Age Calculator">Tree Age Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-6" class="block block-menu block-calc block-calc-ctr7 odd" role="navigation">

<h2 class="block__title block-title">Contractor Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/employer-nics-calculator/" class="menu__link" title="Employer National Insurance Contributions Calculator 2020 / 2021">UK Employer National Insurance Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/business-loan-calculator/" class="menu__link" title="Contractor Business Loan Calculator">Business Loan Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-7-calculator" class="block block-menu block-calc block-calc-ctr8 even" role="navigation">

<h2 class="block__title block-title">Budget &amp; Savings Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/savings-calculator/" class="menu__link" title="Savings Calculator">Savings Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/retirement-savings-calculator/" class="menu__link" title="Retirement Savings Calculator">Retirement Savings Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/electricity-cost-calculator/" class="menu__link" title="Electricity Cost Calculator">Electricity Cost Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cd-calculator/" class="menu__link" title="Certificate of Deposit (CD) Calculator">CD Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/money-market-account-mma-calculator/" class="menu__link" title="Money Market Account (MMA) Calculator">Money Market Account (MMA) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/present-value-calculator/" class="menu__link" title="Present Value Calculator">Present Value Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/future-value-calculator/" class="menu__link" title="Future Value Calculator">Future Value Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/sinking-fund-calculator/" class="menu__link" title="Sinking Fund Calculator">Sinking Fund Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/section-179-deduction-calculator/" class="menu__link" title="Section 179 Deduction Calculator">Section 179 Deduction Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/mileage-reimbursement-calculator/" class="menu__link" title="Mileage Reimbursement Calculator">Mileage Reimbursement Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/payments-calculator/" class="menu__link" title="Payments Calculator">Payments / Repayments Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/net-worth-calculator/" class="menu__link" title="Net Worth Calculator: Calculate Your Personal Net Worth">Net Worth Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-8" class="block block-menu block-calc block-calc-ctr9 odd" role="navigation">

<h2 class="block__title block-title">Loan Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/loan-calculator/" class="menu__link" title="Loan Calculator">Loan Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/student-loan-repayment-calculator/" class="menu__link" title="Student Loan Repayment Calculator">Student Loan Repayment Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/car-affordability-calculator/" class="menu__link" title="Car Affordability Calculator: How much car can I afford?">Car Affordability Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/personal-loan-calculator/" class="menu__link" title="Personal Loan Calculator">Personal Loan Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pay-day-loan-calculator/" class="menu__link" title="Payday Loan Calculator">Payday Loan Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/early-repayment-loan-calculator/" class="menu__link" title="Early Repayment Loan Calculator">Early Repayment Loan Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/car-loan-calculator/" class="menu__link" title="Car Loan Interest Calculator">Car Loan Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/auto-lease-calculator/" class="menu__link" title="Auto Lease Calculator: Calculate Your Car Lease Payment">Auto Lease Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pcp-car-loan-calculator/" class="menu__link" title="PCP Car Loan Calculator">PCP Car Loan Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/lease-vs-buy-car-calculator/" class="menu__link" title="Lease Vs. Buy Car Calculator">Lease Vs. Buy Car Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/equipment-lease-calculator/" class="menu__link" title="Equipment Lease Calculator">Equipment Lease Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/logbook-loan-calculator/" class="menu__link" title="Logbook Loan Calculator">Logbook Loan Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/debt-snowball-calculator/" class="menu__link" title="Debt Snowball Calculator">Debt Snowball Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/credit-card-repayment-calculator/" class="menu__link" title="Credit Card Repayment Calculator">Credit Card Repayment Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/debt-to-income-dti-ratio-calculator/" class="menu__link" title="Debt-to-Income (DTI) Ratio Calculator">Debt-to-Income Ratio Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/dscr-debt-service-coverage-ratio-calculator/" class="menu__link" title="Debt Service Coverage Ratio (DSCR) Calculator">DSCR (Debt Service Coverage Ratio) Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-9" class="block block-menu block-calc block-calc-ctr10 even" role="navigation">

<h2 class="block__title block-title">Forex Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/forex-margin-calculator/" class="menu__link" title="Forex Margin Calculator">Forex Margin Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/forex-fibonacci-calculator/" class="menu__link" title="Forex Fibonacci Calculator">Fibonacci Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/pivot-points-calculator/" class="menu__link" title="Pivot Points Calculator">Pivot Points Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-10-calculator" class="block block-menu block-calc block-calc-ctr11 odd" role="navigation">

<h2 class="block__title block-title">Real Function Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/graphing-calculator/" class="menu__link" title="Online Graphing Calculator">Graphing Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/gradient-calculator/" class="menu__link" title="Gradient Calculator">Gradient Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/slope-calculator/" class="menu__link" title="Online Slope Calculator">Slope Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/total-percent-change-calculator/" class="menu__link" title="Total Percent Change Calculator">Total Percent Change Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/percentage-calculators/" class="menu__link" title="Percentage Calculators">Percentage Calculators</a></li>
<li class="menu__item is-leaf leaf"><a href="/exponents-calculator/" class="menu__link" title="Exponents Calculator">Exponents Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/logarithm-calculator/" class="menu__link" title="Log Calculator">Logarithm Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/factorial-calculator/" class="menu__link" title="Factorial Calculator (n!)">Factorial Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/factoring-calculator/" class="menu__link" title="Factoring Calculator to find all Factors of a Number">Factoring Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/fraction-calculator/" class="menu__link" title="Fraction Calculator">Fraction Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/egyptian-fraction-calculator/" class="menu__link" title="Egyptian Fraction (EF) Calculator">Egyptian Fraction Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/mathematics-power-calculator/" class="menu__link" title="How to calculate Math Powers">Math Powers</a></li>
<li class="menu__item is-leaf leaf"><a href="/summation-calculator/" class="menu__link" title="Summation (Sigma) Notation Calculator">Summation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/modulo-calculator/" class="menu__link" title="Modulo | Mod Calculator">Modulo Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/square-root-calculator/" class="menu__link" title="Square Root Calculator">Square Root Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/gcd-lcm-calculator/" class="menu__link" title="Greatest Common Divisor(GCD) &amp; Least Common Multiple(LCM) Calculator">GCD &amp; LCM Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/big-number-calculator/" class="menu__link" title="Big Number Calculator">Big Number Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/quadratic-equation-calculator/" class="menu__link" title="Quadratic Equation Calculator">Quadratic Equation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/arithmetic-geometric-sequences-calculator/" class="menu__link" title="Arithmetic and Geometric Sequences Calculator">Arithmetic &amp; Geometric Sequences Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/velocity-calculator/" class="menu__link" title="Calculate the velocity of a moving object">Velocity Calculator</a></li>
</ul>
</div>

<div id="block-menu-menu-11-calculator" class="block block-menu block-calc block-calc-ctr12 odd" role="navigation">

<h2 class="block__title block-title">Engineering Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/metals-weight-calculator/" class="menu__link" title="Metals Weight Calculator">Metals Weight Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/thermal-expansion-calculator/" class="menu__link" title="Thermal Expansion Calculator">Thermal Expansion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/speeds-feeds-calculator/" class="menu__link" title="Speeds &amp; Feeds Calculator">Speeds and Feeds Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/flow-rate-calculator/" class="menu__link" title="Flow Rate Calculator">Flow Rate Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/friction-loss-calculator/" class="menu__link" title="Friction Loss Calculator">Friction Loss Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/roll-length-calculator/" class="menu__link" title="Roll Length Calculator">Roll Length Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/resistor-color-code-calculator/" class="menu__link" title="Resistor Color Code Calculator">Resistor Color Code Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/voltage-divider-calculator/" class="menu__link" title="Voltage Divider Calculator">Voltage Divider Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rms-calculator/" class="menu__link" title="RMS Voltage Calculator">RMS Voltage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/wheatstone-bridge-calculator/" class="menu__link" title="Wheatstone Bridge Calculator">Wheatstone Bridge Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/resonant-frequency-calculator/" class="menu__link" title="Resonant Frequency Calculator">Resonant Frequency Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/crossover-calculator/" class="menu__link" title="Crossover Calculator">Crossover Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/transformer-calculator/" class="menu__link" title="Transformer Calculator">Transformer Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/motor-fla-calculator/" class="menu__link" title="Motor Full Load Amperage (FLA) Calculator">Motor FLA Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/power-to-weight-ratio-calculator/" class="menu__link" title="Power to Weight Ratio (PWR) Calculator">Power to Weight Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/gas-oil-ratio-calculator/" class="menu__link" title="Gas Oil Mix Ratio Calculator">Gas Oil Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/skid-speed-calculator/" class="menu__link" title="Skid Speed Calculator">Skid Speed Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/quarter-mile-calculator/" class="menu__link" title="Quarter Mile Calculator">Quarter Mile Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/compression-ratio-calculator/" class="menu__link" title="Compression Ratio Calculator">Compression Ratio Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/boat-prop-calculator/" class="menu__link" title="Boat Propeller Calculator">Boat Propeller Calculator</a></li>
</ul>
</div>

<div id="block-menu-menu-12-calculator" class="block block-menu block-calc block-calc-ctr13 even" role="navigation">

<h2 class="block__title block-title">Tax Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/car-tax-calculator/" class="menu__link" title="UK Road Tax or VED Calculator">Car Tax Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/small-business-rate-relief-calculator/" class="menu__link" title="Small Business Rate Relief Calculator">Small Business Rate Relief Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/stamp-duty-calculator/" class="menu__link" title="Stamp Duty Tax Calculator">Stamp Duty Tax Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/online-vat-calculator/" class="menu__link" title="Value Added Tax Calculator">Online VAT Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/gift-tax-calculator/" class="menu__link" title="Gift Tax Calculator">Gift Tax Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/us-sales-tax-calculator/" class="menu__link" title="United States Sales Tax Calculator">US Sales Tax Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/us-property-tax-calculator/" class="menu__link" title="United States Property Tax Calculator">US Property Tax Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-13-calculator" class="block block-menu block-calc block-calc-ctr14 even" role="navigation">

<h2 class="block__title block-title">Volume Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/cone-volume-calculator/" class="menu__link" title="Volume of a Cone Calculator">Volume of a Cone Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cube-volume-calculator/" class="menu__link" title="Volume of a Cube Calculator">Volume of a Cube Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cylinder-volume-calculator/" class="menu__link" title="How to calculate Volume Cylinder">Volume of a Cylinder Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ellipse-volume-calculator/" class="menu__link" title="How to calculate Volume Ellipsoid">Volume of an Ellipsoid Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/irregular-prism-volume-calculator/" class="menu__link" title="Volume of an Irregular Prism Calculator">Volume of an Irregular Prism Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/square-pyramid-volume-calculator/" class="menu__link" title="Volume of a Pyramid Calculator">Volume of a Pyramid Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rectangular-prism-volume-calculator/" class="menu__link" title="Volume of a Rectanglular Prism Calculator">Volume of a Rectanglular Prism Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/sphere-volume-calculator/" class="menu__link" title="How to calculate Volume Sphere">Volume of a Sphere Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/triangular-pyramid-volume-calculator/" class="menu__link" title="Volume of a Triangle Pyramid Calculator">Volume of a Triangle Pyramid Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pool-volume-calculator/" class="menu__link" title="Pool Volume Calculator">Pool Volume Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/mass-density-volume-calculator/" class="menu__link" title="Mass, Density &amp; Volume Calculator">Mass, Density &amp; Volume Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-14" class="block block-menu block-calc block-calc-ctr15 odd" role="navigation">

<h2 class="block__title block-title">2D Shape Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/advanced-polygon-calculator/" class="menu__link" title="Advanced Polygon Calculator">Advanced Polygon Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/arc-of-circle-calculator/" class="menu__link" title="Arc Of Circle Calculator">Arc Of Circle Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/circle-calculator/" class="menu__link" title="Circle Calculator">Circle Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rhombus-calculator/" class="menu__link" title="Rhombus Calculator">Rhombus Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/stadium-geometric-shape-calculator/" class="menu__link" title="Stadium Geometric Shape Calculator">Stadium Geometric Shape Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/regular-polygon-calculator/" class="menu__link" title="Regular Polygon Calculator">Regular Polygon Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pythagoras-calculator/" class="menu__link" title="Pythagoras Triangle Calculator">Pythagoras Triangle Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/square-and-cube-calculator/" class="menu__link" title="Square Calculator">Square Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-15-calculators" class="block block-menu block-calc block-calc-ctr16 even" role="navigation">

<h2 class="block__title block-title">3D Shape Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/cylinder-calculator/" class="menu__link" title="Cylinder Calculator">Cylinder Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/square-pyramid-calculator/" class="menu__link" title="Square Pyramid Calculator">Square Pyramid Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/frustum-calculator/" class="menu__link" title="Frustum Calculator">Frustum Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/prism-calculator/" class="menu__link" title="Prism Calculator">Prism Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/sphere-calculator/" class="menu__link" title="Sphere Calculator">Sphere Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/egg-surface-area-and-volume-calculator/" class="menu__link" title="Egg Surface Area and Volume Calculator">Egg Surface Area and Volume Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-16-calculator" class="block block-menu block-calc block-calc-ctr17 odd" role="navigation">

<h2 class="block__title block-title">Logistics Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/freight-class-calculator/" class="menu__link" title="Freight Class Calculator">Freight Class Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/density-calculator/" class="menu__link" title="Freight Density and Ratio Calculator">Density Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/volumetric-calculator/" class="menu__link" title="Volumetric Weight Calculator">Volumetric Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-17" class="block block-menu block-calc block-calc-ctr18 even" role="navigation">

<h2 class="block__title block-title">HRM Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/holiday-entitlement-calculator/" class="menu__link" title="Holiday Entitlement Calculator">Holiday Entitlement Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/overtime-calculator/" class="menu__link" title="Overtime (OT) Calculator">Overtime Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/bradford-factor-calculator/" class="menu__link" title="Bradford Factor Calculator">Bradford Factor Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cost-per-hire-calculator/" class="menu__link" title="Cost Per Hire Calculator">Cost Per Hire Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/true-cost-of-an-employee-calculator/" class="menu__link" title="True Cost of an Employee Calculator">True Cost of an Employee Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/labor-cost-per-employee-calculator/" class="menu__link" title="Labour Cost Calculator">Labour Cost Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/turnover-rate-calculator/" class="menu__link" title="Turnover Rate Calculator">Turnover Rate Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/revenue-per-employee-calculator/" class="menu__link" title="Revenue Per Employee Calculator">Revenue Per Employee Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/redundancy-calculator/" class="menu__link" title="Redundancy Payment Calculator">Redundancy Payment Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-18" class="block block-menu block-calc block-calc-ctr19 odd" role="navigation">

<h2 class="block__title block-title">Sales &amp; Investments Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/inflation-calculator/" class="menu__link" title="US Inflation Calculator | UK Inflation Calculator">Inflation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/discount-calculator/" class="menu__link" title="Discount Calculator">Discount Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/shopping-online-vs-in-store-calculator/" class="menu__link" title="Shopping Online Vs Shopping In-Store Calculator">Shopping Online Vs In-Store Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/profit-calculator/" class="menu__link" title="Profit Calculator">Profit Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/commission-calculator/" class="menu__link" title="Commission Calculator">Commission Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/discounted-payback-period-calculator/" class="menu__link is-active-trail active-trail active" title="Discounted Payback Period (DPP) Calculator">Discounted Payback Period Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/deadweight-loss-calculator/" class="menu__link" title="Deadweight Loss Calculator">Deadweight Loss (DWL) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/profitability-index-calculator/" class="menu__link" title="Profitability Index (PI) Calculator">Profitability Index Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/simple-and-compound-interest-calculator/" class="menu__link" title="Simple &amp; Compound Interest Calculator">Simple and Compound Interest Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cagr-calculator/" class="menu__link" title="CAGR (Compound Annual Growth Rate) Calculator">Compound Annual Growth Rate Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/roi-return-on-investment-calculator/" class="menu__link" title="Return on Investment (ROI) Calculator">ROI (Return on Investment) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/acid-test-quick-ratio-calculator/" class="menu__link" title="Acid Test Ratio (Quick Ratio) Calculator ">Acid Test Ratio (Quick Ratio) Calculator </a></li>
<li class="menu__item is-leaf leaf"><a href="/current-ratio-calculator/" class="menu__link" title="Current Ratio Calculator">Current Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/debt-to-equity-ratio-calculator/" class="menu__link" title="Debt to Equity (D/E) Ratio Calculator">Debt to Equity Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/debt-to-gdp-ratio-calculator/" class="menu__link" title="Debt-to-GDP Ratio Calculator">Debt-to-GDP Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rule-of-72-calculator/" class="menu__link" title="Rule of 72 Calculator">Rule of 72 Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/doubling-and-tripling-time-calculator/" class="menu__link" title="Doubling and Tripling Time Calculator">Doubling &amp; Tripling Time Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/invoice-calculator/" class="menu__link" title="Invoice Calculator">Invoice Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/enterprise-value-calculator/" class="menu__link" title="Enterprise Value (EV) Calculator">Enterprise Value Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ebitda-calculator/" class="menu__link" title="EBITDA Calculator: Calculate Earnings Before Interest, Taxes, Depreciation and Amortization">EBITDA Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/price-elasticity-of-demand-calculator/" class="menu__link" title="Price Elasticity of Demand (PED) Calculator">Price Elasticity of Demand Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/inventory-turnover-calculator/" class="menu__link" title="Inventory Turnover Calculator">Inventory Turnover Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/gdp-calculator/" class="menu__link" title="GDP Calculator">Gross Domestic Product (GDP) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/perpetuity-calculator/" class="menu__link" title="Perpetuity Calculator">Perpetuity Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/effective-annual-rate-calculator/" class="menu__link" title="Effective Annual Rate Calculator">Effective Annual Rate Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/break-even-calculator/" class="menu__link" title="Break-Even Calculator">Break Even Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/dime-sale-calculator/" class="menu__link" title="Dime Sale Calculator">Dime Sale Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/margin-calculator/" class="menu__link" title="Margin Calculator">Margin Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/roic-calculator/" class="menu__link" title="Return on Invested Capital (ROIC) Calculator">ROIC Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/eva-calculator/" class="menu__link" title="Economic Value Added (EVA) Calculator">EVA Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/geometric-average-return-calculator/" class="menu__link" title="Geometric Average Return Calculator">Geometric Average Return (GAR) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/capm-calculator/" class="menu__link" title="Capital Asset Pricing Model (CAPM) Calculator">CAPM Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/wacc-calculator/" class="menu__link" title="Weighted Average Cost of Capital (WACC) Calculator">WACC Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/eoq-calculator/" class="menu__link" title="EOQ (Economic Order Quantity) Calculator">Economic Order Quantity Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/hhi-calculator/" class="menu__link" title="Herfindahl-Hirschman Index (HHI) Calculator">Herfindahl-Hirschman Index Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cash-conversion-cycle-calculator/" class="menu__link" title="Cash Conversion Cycle (CCC) Calculator">Cash Conversion Cycle Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/learning-curve-calculator/" class="menu__link" title="Learning Curve Calculator">Learning Curve Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/dividend-discount-model-ddm-calculator/" class="menu__link" title="Dividend Discount Model (DDM) Calculator">Dividend Discount Model Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/treasury-bills-calculator/" class="menu__link" title="US Treasury Bill Calculator">US Treasury Bill Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/tax-equivalent-yield-calculator/" class="menu__link" title="Tax-Equivalent Yield (TEY) Calculator">Tax-Equivalent Yield Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/stock-calculator/" class="menu__link" title="Stock Calculator">Stock Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/earnings-per-share-eps-calculator/" class="menu__link" title="Earnings per Share (EPS) Calculator">Earnings per Share Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rsi-calculator/" class="menu__link" title="Relative Strength Index (RSI) Calculator">Relative Strength Index Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/bond-yield-to-maturity-calculator/" class="menu__link" title="Bond Yield to Maturity Calculator">Bond Yield to Maturity Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/prorated-rent-calculator/" class="menu__link" title="Prorated Rent Calculator">Prorated Rent Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/home-appreciation-calculator/" class="menu__link" title="Home Appreciation Calculator | Future Home Value Calculator">Home Appreciation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cap-rate-calculator/" class="menu__link" title="Cap Rate Calculator: Calculate Your Real Estate Capitalization Rate">Cap Rate Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rent-split-calculator/" class="menu__link" title="Rent Split Calculator: Divide Your Rent Fairly">Rent Split Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/college-cost-calculator/" class="menu__link" title="College Cost Calculator">College Cost Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-19-calculator" class="block block-menu block-calc block-calc-ctr20 even" role="navigation">

<h2 class="block__title block-title">Grade &amp; GPA Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/grade-calculator/" class="menu__link" title="Grade Calculator">Grade Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/gpa-calculator/" class="menu__link" title="GPA Calculator">GPA Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-20" class="block block-menu block-calc block-calc-ctr21 odd" role="navigation">

<h2 class="block__title block-title">Conversion Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/scientific-notation-calculator-converter/" class="menu__link" title="Scientific Notation Calculator &amp; Converter">Scientific Notation Calculator &amp; Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/sig-fig-significant-figures-calculator/" class="menu__link" title="Significant Figures Calculator">Sig Fig (Significant Figures) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/probability-odds-conversion-calculator/" class="menu__link" title="Probability &amp; Odds Conversion Calculator">Probability and Odds Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/data-storage-conversion-calculator/" class="menu__link" title="Data Storage Conversion Calculator">Data Storage Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/binary-to-decimal-calculator/" class="menu__link" title="Binary to Decimal Converter">Binary to Decimal Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/repeating-decimal-to-fraction-conversion-calculator/" class="menu__link" title="Repeating Decimal to Fraction Conversion Calculator">Repeating Decimal to Fraction Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/degrees-to-radians-converter/" class="menu__link" title="Degrees to Radians Converter">Degrees to Radians Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/distance-converter/" class="menu__link" title="Distance Converter">Distance Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/number-format-converter/" class="menu__link" title="Number Format Converter">Number Format Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/rgb-hex-converter/" class="menu__link" title="RGB to Hex Converter | Hex to RGB Converter">RGB / Hex Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rgb-to-grayscale-conversion-calculator/" class="menu__link" title="RGB to Grayscale Converter">RGB to Grayscale Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/speed-distance-time-calculator/" class="menu__link" title="Speed Distance Time Calculator">Speed Distance Time Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/alternative-fuels-conversion-calculator/" class="menu__link" title="Alternative Fuels Conversion Calculator">Alternative Fuels Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/torque-conversion-calculator/" class="menu__link" title="Torque Conversion Calculator">Torque Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/force-converter/" class="menu__link" title="Force Converter">Force Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/pressure-converter/" class="menu__link" title="Pressure Converter">Pressure Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/temperature-converter/" class="menu__link" title="Temperature Converter">Temperature Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/wind-speed-converter/" class="menu__link" title="Wind Speed Conversion Calculator">Wind Speed Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/roman-numeral-converter/" class="menu__link" title="Roman Numerals Converter">Roman Numerals Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/height-converter/" class="menu__link" title="Height Converter">Height Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/weight-converter/" class="menu__link" title="Weight Conversion Calculator">Weight Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/metric-to-imperial-converter/" class="menu__link" title="Metric Converter">Metric Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/imperial-to-metric-converter/" class="menu__link" title="Imperial Converter">Imperial Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/cooking-conversion-calculator/" class="menu__link" title="Cooking Measurement Conversion Calculator">Cooking Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/convection-oven-calculator/" class="menu__link" title="Convection Oven Conversion Calculator">Convection Oven Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/numbers-to-words-converter/" class="menu__link" title="Convert Numbers to Words">Numbers to Words Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/basis-points-conversion-calculator/" class="menu__link" title="Basis Points (BPS) Conversion Calculator">Basis Points Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/paper-size-conversion-calculator/" class="menu__link" title="Paper Size Conversion Calculator">Paper Size Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/currency-converter/" class="menu__link" title="Currency Converter Calculator">Currency Converter Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ring-size-converter/" class="menu__link" title="Ring Size Converter | Online Ring Sizer">Ring Size Converter</a></li>
<li class="menu__item is-leaf leaf"><a href="/scale-conversion-calculator/" class="menu__link" title="Scale Conversion Calculator">Scale Conversion Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/bra-size-calculator/" class="menu__link" title="Bra Size Calculator: US &amp; CA, UK, EU">Bra Size Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/shoe-size-converter/" class="menu__link" title="Shoe Size Conversion Calculator: US &amp; CA, UK, EU, AU">Shoe Size Converter</a></li>
</ul>
</div>
<div id="block-menu-menu-21" class="block block-menu block-calc block-calc-ctr22 even" role="navigation">

<h2 class="block__title block-title">Ratio Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/aspect-ratio-calculator/" class="menu__link" title="Aspect Ratio Calculator">Aspect Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/golden-ratio-calculator/" class="menu__link" title="Golden Ratio Calculator">Golden Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/silver-ratio-calculator/" class="menu__link" title="Silver Ratio Calculator">Silver Ratio Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/ratio-calculator/" class="menu__link" title="Ratio Calculator">Ratio Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-22" class="block block-menu block-calc block-calc-ctr24 last even" role="navigation">

<h2 class="block__title block-title">Sports &amp; Health Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/body-mass-index-calculator/" class="menu__link" title="Body Mass Index Calculator">Body Mass Index Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/body-fat-calculator/" class="menu__link" title="Body Fat Calculator">Body Fat Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/weight-loss-percentage-calculator/" class="menu__link" title="Weight Loss Percentage Calculator">Weight Loss Percentage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/bai-calculator/" class="menu__link" title="BAI Calculator">Body Adiposity Index (BAI) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/skinfold-calculator/" class="menu__link" title="Skinfold Body Fat Calculator">Skinfold Body Fat Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ffmi-fat-free-mass-index-calculator/" class="menu__link" title="FFMI Calculator: Calculate Your Fat-Free Mass Index">FFMI (Fat-Free Mass Index) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/lean-body-mass-lbm-calculator/" class="menu__link" title="Lean Body Mass (LBM) Calculator">Lean Body Mass Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ideal-body-weight-ibw-calculator/" class="menu__link" title="Ideal Body Weight (IBW) Calculator">Ideal Body Weight Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/bsa-calculator/" class="menu__link" title="Body Surface Area (BSA) Calculator">Body Surface Area Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/body-shape-calculator/" class="menu__link" title="Body Shape Calculator: Find Out Your Body Shape">Body Shape Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/water-intake-calculator/" class="menu__link" title="Daily Water Intake Calculator">Water Intake Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cold-water-survival-time-calculator/" class="menu__link" title="Cold Water Survival Time Calculator">Cold Water Survival Time Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/apft-calculator/" class="menu__link" title="Army Physical Fitness Test (APFT) Calculator">APFT Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/acft-calculator/" class="menu__link" title="Army Combat Fitness Test (ACFT) Calculator">ACFT Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/steps-to-miles-calculator/" class="menu__link" title="Steps to Miles Calculator | Convert Your Steps to Miles and Kilometers">Steps to Miles Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/bench-press-calculator/" class="menu__link" title="Bench Press Calculator">Bench Press Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/wilks-calculator/" class="menu__link" title="Wilks Calculator">Wilks Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/tdee-bmr-calculator/" class="menu__link" title="Free TDEE and BMR Calculator">TDEE and BMR Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/estimated-energy-requirement-eer-calculator/" class="menu__link" title="Estimated Energy Requirement (EER) Calculator">Estimated Energy Requirement Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/macronutrient-calculator/" class="menu__link" title="Macro Calculator">Macronutrient Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/protein-calculator/" class="menu__link" title="Protein Calculator">Protein Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/waist-to-hip-ratio-calculator/" class="menu__link" title="Waist-to-Hip Ratio (WHR) Calculator">Waist-to-Hip Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/calorie-calculator/" class="menu__link" title="Calorie Calculator">Calorie Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/heart-rate-calculator/" class="menu__link" title="Heart Rate Calculator">Heart Rate Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/qtc-calculator/" class="menu__link" title="QTc Calculator">Corrected QT Interval Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pregnancy-calculator/" class="menu__link" title="Pregnancy Calculator">Pregnancy Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pregnancy-weight-gain-calculator/" class="menu__link" title="Pregnancy Weight Gain Calculator">Pregnancy Weight Gain Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ovulation-calculator/" class="menu__link" title="Ovulation Calculator">Ovulation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pythagorean-expectation-calculator/" class="menu__link" title="Pythagorean Expectation Calculator">Pythagorean Expectation Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/winning-percentage-calculator/" class="menu__link" title="Win Percentage Calculator">Winning Percentage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/league-table-creator/" class="menu__link" title="League Table Creator">League Table Creator &amp; Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/running-pace-calculator/" class="menu__link" title="Running Pace Calculator">Running Pace Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/run-time-calculator/" class="menu__link" title="Run Time Calculator">Run Time Calculator</a></li>
</ul>
</div>
<div id="block-menu-menu-23-calculator" class="block block-menu block-calc block-calc-ctr23 odd" role="navigation">

<h2 class="block__title block-title">Other Calculators</h2>
<ul class="menu">
<li class="menu__item is-leaf first leaf"><a href="/fegli-calculator/" class="menu__link" title="FEGLI (Federal Employees Group Life Insurance) Calculator">FEGLI Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/rice-to-water-ratio-calculator/" class="menu__link" title="Rice to Water Ratio Calculator">Rice-to-Water Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/coffee-to-water-ratio-calculator/" class="menu__link" title="Coffee to Water Ratio Calculator">Coffee-to-Water Ratio Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/va-disability-calculator/" class="menu__link" title="VA Disability Rating &amp; Compensation Calculator">VA Disability Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ppi-pixels-per-inch-calculator/" class="menu__link" title="PPI (Pixels Per Inch) Calculator">PPI Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/tv-viewing-distance-calculator/" class="menu__link" title="TV Viewing Distance Calculator">TV Viewing Distance Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/flesch-kincaid-calculator/" class="menu__link" title="Flesch Kincaid Calculator">Flesch Kincaid Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/running-record-calculator/" class="menu__link" title="Running Record Calculator">Running Record Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/luhn-algorithm-calculator/" class="menu__link" title="Luhn Algorithm Calculator">Luhn Algorithm Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/money-weight-calculator/" class="menu__link" title="Money Weight Calculator">Money Weight Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/diamond-weight-calculator/" class="menu__link" title="Diamond Carat Weight Calculator">Diamond Weight Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/ip-subnet-calculator/" class="menu__link" title="IP Subnet Calculator">IP Subnet Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/scientific-calculator/" class="menu__link" title="Scientific Calculator">Scientific Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/effective-population-size-calculator/" class="menu__link" title="Effective Population Size Calculator">Effective Population Size Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/fuel-calculator/" class="menu__link" title="Fuel Calculator">Fuel Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/fuel-economy-calculator/" class="menu__link" title="Fuel Economy Calculator">Fuel Economy Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/bike-size-calculator/" class="menu__link" title="Bike Size Calculator">Bike Size Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/tire-size-calculator/" class="menu__link" title="Tire Size Calculator">Tire Size Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/estimated-time-of-arrival-eta-calculator/" class="menu__link" title="Estimated Time of Arrival Calculator">Estimated Time of Arrival (ETA) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/lease-mileage-calculator/" class="menu__link" title="Lease Mileage Calculator">Lease Mileage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/cigarette-calculator/" class="menu__link" title="Cigarette Calculator">Cigarette Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/abv-alcohol-by-volume-calculator/" class="menu__link" title="Alcohol By Volume Calculator">ABV (Alcohol By Volume) Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/blood-alcohol-content-calculator/" class="menu__link" title="Blood Alcohol Content Calculator">Blood Alcohol Content Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/concrete-calculator/" class="menu__link" title="Concrete Calculator">Concrete Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/tile-calculator/" class="menu__link" title="Tile Calculator">Tile Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/grout-calculator/" class="menu__link" title="Grout Calculator">Grout Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/paint-calculator/" class="menu__link" title="Paint Calculator">Paint Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/room-size-calculator/" class="menu__link" title="Room Size Calculator">Room Size Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/square-footage-calculator/" class="menu__link" title="Square Footage Calculator">Square Footage Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/board-foot-calculator/" class="menu__link" title="Board Foot Calculator">Board Foot Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/meat-cooking-time-calculator/" class="menu__link" title="Meat Cooking Time Calculator">Meat Cooking Time Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/meatball-calculator/" class="menu__link" title="Meatball Calculator">Meatball Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pizza-calculator/" class="menu__link" title="Pizza Calculator | How Many Pizzas Do I Need?">Pizza Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/pizza-tip-calculator/" class="menu__link" title="Pizza Tip Calculator">Pizza Tip Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/tip-calculator/" class="menu__link" title="Tip Calculator">Tip Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/hand-sanitizer-proportions-calculator/" class="menu__link" title="Hand Sanitizer Proportions Calculator">Hand Sanitizer Proportions Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/inside-car-temperature-calculator/" class="menu__link" title="Inside Car Temperature Calculator">Inside Car Temperature Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/snow-calculator/" class="menu__link" title="Snow Calculator">Snow Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/wind-chill-calculator/" class="menu__link" title="Wind Chill Calculator">Wind Chill Calculator</a></li>
<li class="menu__item is-leaf leaf"><a href="/dew-point-calculator/" class="menu__link" title="Dew Point Calculator">Dew Point Calculator</a></li>
<li class="menu__item is-leaf last leaf"><a href="/heat-index-calculator/" class="menu__link" title="Heat Index Calculator">Heat Index Calculator</a></li>
</ul>
</div>
<div align="center" class="Begin" id="adsg3" style="width:300px;padding-top:0px;padding-bottom:0px;margin-top:10px"></div>
</section>
</aside> </div>
<div id="footer-wrap"><style type="text/css">@media ( max-width: 500px){.text {padding:8px!important;font-size:11px}}</style>
<div id="footer-after-left">
<div class="region region-footer-after-left">
<div id="block-block-13" class="block block-block copyright-block first last odd">
<div class="logo" style="float: left; margin-right: 15px; padding-bottom: 15px;">
<img style="display: block;" src="/i/logos_foot.png" alt="" width="157" height="45"/></div>
<div class="text">

© Copyright <a style="color:#000000; text-decoration:none;" href="/">Good Calculators</a> 2021. All Rights Reserved
<br/><a href="/widgets/">Widgets</a> <a href="/privacy/">Privacy</a> <a title="About Us | Contact Us" href="/contact/#about">About Us</a>
</div>

</div>
</div>
</div>
<div id="footer-after-right">
<div class="region region-footer-after-right">
<div id="block-block-14" class="block block-block counters-block first last odd" style="margin:0;">
<div style="float:right; margin-top: 12px; padding-right:0px;">
<div style="float:left; margin-right:8px; margin-top:2px;">Join with us</div>
<a style="display:inline-block;vertical-align:bottom;width:24px;height:24px;margin:0 6px 2px 0;padding:0;outline:none;background:url(//goodcalculators.com/i/icons_black.png) -24px 0 no-repeat" rel="noopener noreferrer nofollow" href="//www.facebook.com/goodcalculators/" title="Facebook" target="_blank"></a>
<a style="display:inline-block;vertical-align:bottom;width:24px;height:24px;margin:0 6px 2px 0;padding:0;outline:none;background:url(//goodcalculators.com/i/icons_black.png) -120px 0 no-repeat" rel="noopener noreferrer nofollow" href="//twitter.com/goodcalcs" title="Twitter" target="_blank"></a>
</div>

<div class="clearfix"></div>
</div>
</div>
</div>
<div class="clearfix"></div> </div>

</div>
</div>
<script type="text/javascript" src="/js/share42.js"></script>

<script type="text/javascript">
var nelms = document.querySelectorAll('.adsbygoogle');
for(var nel = 0; nel < nelms.length; nel++) {
(adsbygoogle = window.adsbygoogle || []).push({});
}
</script>

<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12&appId=249283822120782
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>
<script type="text/javascript">
(function() {
var cx = '009030167060906581427:9bja0k3sfvu
var gcse = document.createElement('script');
gcse.type = 'text/javascript
gcse.async = true;
gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(gcse, s);
})();
</script>

<script type='text/javascript' style='display:none;' async>
__ez.queue.addFile('/detroitchicago/edmonton.webp', '/detroitchicago/edmonton.webp?a=a&cb=2&shcb=34', true, ['/detroitchicago/minneapolis.js'], true, false, false, false);
__ez.queue.addFile('/porpoiseant/jellyfish.webp', '/porpoiseant/jellyfish.webp?a=a&cb=2&shcb=34', false, [], true, false, false, false);
</script>

<script>var _audins_dom="goodcalculators_com",_audins_did=124911;__ez.queue.addDelayFunc("audins.js","__ez.script.add", "//go.ezoic.net/detroitchicago/audins.js?cb=194-2");</script><noscript><div style="display:none;"><img src="//pixel.quantserve.com/pixel/p-31iz6hfFutd16.gif?labels=Domain.goodcalculators_com,DomainId.124911" border="0" height="1" width="1" alt="Quantcast"/></div></noscript>
<script type="text/javascript" data-cfasync="false"></script>
<script>__ez.queue.addFile('/tardisrocinante/vitals.js', '/tardisrocinante/vitals.js?gcb=2&cb=3', false, ['/detroitchicago/minneapolis.js'], true, false, true, false);</script>
</body>
</html>