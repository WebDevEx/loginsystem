// JavaScript Document
        //COMPANY A
		var arrHead = new Array();
        arrHead = ['', 'Period'];

        function addRowPeriod() {
            var empTab = document.getElementById('tab_logic');

            var rowCnt = empTab.rows.length;
            var tr = empTab.insertRow(rowCnt);
            tr = empTab.insertRow(rowCnt);

            for (var c = 0; c < arrHead.length; c++) {
                var td = document.createElement('td');
                td = tr.insertCell(c);

                if (c == 0) {
                    var button = document.createElement('input');

                    button.setAttribute('type', 'button');
                    button.setAttribute('value', 'Remove Year');

                    button.setAttribute('onclick', 'removeRow(this)');

                    td.appendChild(button);
                } else {
                    var ele = document.createElement('input');
                    ele.setAttribute('type', 'text');
                    ele.setAttribute('value', '');
                    ele.setAttribute('name', 'yr[]');
                    ele.setAttribute('class', 'form-control');

                    td.appendChild(ele);
                }
            }
        }

        function removeRow(oButton) {
            var empTab = document.getElementById('tab_logic');
            empTab.deleteRow(oButton.parentNode.parentNode.rowIndex);
        }

//COMPANY B
 var arrHead2 = new Array();
 arrHead2 = ['', 'Period'];

        function addRowPeriod2() {
            var empTab = document.getElementById('tab_logic2');

            var rowCnt = empTab.rows.length;
            var tr = empTab.insertRow(rowCnt);
            tr = empTab.insertRow(rowCnt);

            for (var c = 0; c < arrHead.length; c++) {
                var td = document.createElement('td');
                td = tr.insertCell(c);

                if (c == 0) {
                    var button = document.createElement('input');

                    button.setAttribute('type', 'button');
                    button.setAttribute('value', 'Remove Year');

                    button.setAttribute('onclick', 'removeRow2(this)');

                    td.appendChild(button);
                } else {
                    var ele = document.createElement('input');
                    ele.setAttribute('type', 'text');
                    ele.setAttribute('value', '');
                    ele.setAttribute('name', 'yr2[]');
                    ele.setAttribute('class', 'form-control');

                    td.appendChild(ele);
                }
            }
        }

        function removeRow2(oButton) {
            var empTab = document.getElementById('tab_logic2');
            empTab.deleteRow(oButton.parentNode.parentNode.rowIndex);
        }

//COMPANY C
 var arrHead3 = new Array();
 arrHead3 = ['', 'Period'];

        function addRowPeriod3() {
            var empTab = document.getElementById('tab_logic3');

            var rowCnt = empTab.rows.length;
            var tr = empTab.insertRow(rowCnt);
            tr = empTab.insertRow(rowCnt);

            for (var c = 0; c < arrHead.length; c++) {
                var td = document.createElement('td');
                td = tr.insertCell(c);

                if (c == 0) {
                    var button = document.createElement('input');

                    button.setAttribute('type', 'button');
                    button.setAttribute('value', 'Remove Year');

                    button.setAttribute('onclick', 'removeRow3(this)');

                    td.appendChild(button);
                } else {
                    var ele = document.createElement('input');
                    ele.setAttribute('type', 'text');
                    ele.setAttribute('value', '');
                    ele.setAttribute('name', 'yr3[]');
                    ele.setAttribute('class', 'form-control');

                    td.appendChild(ele);
                }
            }
        }

        function removeRow3(oButton) {
            var empTab = document.getElementById('tab_logic3');
            empTab.deleteRow(oButton.parentNode.parentNode.rowIndex);
        }
		
		
