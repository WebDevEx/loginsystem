// JavaScript Document

//COMPANY A

 var arrHead = new Array();
 arrHead = ['', 'Period'];
 
 function addRowPeriodDPP() {
            var empTab = document.getElementById('tab_logic_dpp');

            var rowCnt = empTab.rows.length;
            var tr = empTab.insertRow(rowCnt);
            tr = empTab.insertRow(rowCnt);

            for (var c = 0; c < arrHead.length; c++) {
                var td = document.createElement('td');
                td = tr.insertCell(c);

                if (c == 0) {
                    var button = document.createElement('input');

                    button.setAttribute('type', 'button');
                    button.setAttribute('value', 'Remove Year');

                    button.setAttribute('onclick', 'removeRowDPP(this)');

                    td.appendChild(button);
                } else {
                    var ele = document.createElement('input');
                    ele.setAttribute('type', 'text');
                    ele.setAttribute('value', '');
                    ele.setAttribute('name', 'yr[]');
                    ele.setAttribute('class', 'form-control');

                    td.appendChild(ele);
                }
            }
        }

        function removeRowDPP(oButton) {
            var empTab = document.getElementById('tab_logic_dpp');
            empTab.deleteRow(oButton.parentNode.parentNode.rowIndex);
        }

//--------------------------------------------------

//COMPANY B

var arrHead2 = new Array();
 arrHead2 = ['', 'Period'];
 
 function addRowPeriodDPP2() {
            var empTab = document.getElementById('tab_logic_dpp2');

            var rowCnt = empTab.rows.length;
            var tr = empTab.insertRow(rowCnt);
            tr = empTab.insertRow(rowCnt);

            for (var c = 0; c < arrHead2.length; c++) {
                var td = document.createElement('td');
                td = tr.insertCell(c);

                if (c == 0) {
                    var button = document.createElement('input');

                    button.setAttribute('type', 'button');
                    button.setAttribute('value', 'Remove Year');

                    button.setAttribute('onclick', 'removeRowDPP2(this)');

                    td.appendChild(button);
                } else {
                    var ele = document.createElement('input');
                    ele.setAttribute('type', 'text');
                    ele.setAttribute('value', '');
                    ele.setAttribute('name', 'yr2[]');
                    ele.setAttribute('class', 'form-control');

                    td.appendChild(ele);
                }
            }
        }

        function removeRowDPP2(oButton) {
            var empTab = document.getElementById('tab_logic_dpp2');
            empTab.deleteRow(oButton.parentNode.parentNode.rowIndex);
        }

//---------------------------------------------------


//COMPANY C

var arrHead3 = new Array();
 arrHead3 = ['', 'Period'];
 
 function addRowPeriodDPP3() {
            var empTab = document.getElementById('tab_logic_dpp3');

            var rowCnt = empTab.rows.length;
            var tr = empTab.insertRow(rowCnt);
            tr = empTab.insertRow(rowCnt);

            for (var c = 0; c < arrHead3.length; c++) {
                var td = document.createElement('td');
                td = tr.insertCell(c);

                if (c == 0) {
                    var button = document.createElement('input');

                    button.setAttribute('type', 'button');
                    button.setAttribute('value', 'Remove Year');

                    button.setAttribute('onclick', 'removeRowDPP3(this)');

                    td.appendChild(button);
                } else {
                    var ele = document.createElement('input');
                    ele.setAttribute('type', 'text');
                    ele.setAttribute('value', '');
                    ele.setAttribute('name', 'yr3[]');
                    ele.setAttribute('class', 'form-control');

                    td.appendChild(ele);
                }
            }
        }

        function removeRowDPP3(oButton) {
            var empTab = document.getElementById('tab_logic_dpp3');
            empTab.deleteRow(oButton.parentNode.parentNode.rowIndex);
        }

//---------------------------------------------------
	