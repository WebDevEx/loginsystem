<?php

// Fetching NPP data
$sql = "SELECT * FROM npv where userID = " . $_SESSION['id'];
$result = $con->query($sql);
$npv_list = [];
$dpp_array = [];

if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        array_push($npv_list, $row);
    }
}

function npv($rate, $values, $year)
{
    $npv = 0;
    for ($i = $year; $i >= 0; $i -= 1) {
        $npv = ($values[$i] + $npv) / (1 + $rate);
    }
    return number_format($npv, 2, '.', ',');
}

if ($_POST) {
    // Processing Form Data
    if ($_POST['type'] == 'npp') {
        if (isset($_POST['iv']) && isset($_POST['dr'])) {
            // Calculating NPP
            $NPV = npv($_POST['dr'], $_POST['yr'], count($_POST['yr']));
            $iv = $_POST['iv'];
            $dr = $_POST['dr'];
            $years = count($_POST['yr']);
            $userId = $_SESSION['id'];

            // Inserting data into database
            $sql = "INSERT INTO npv (initial_investment, discount_rate, years, npv, userID)
                    VALUES ($iv, $dr, $years, $NPV, $userId)";

            if ($con->query($sql) === TRUE) {
                header("Refresh:0");
            } else {
                //echo "Error: " . $sql . "<br>" . $con->error;
            }
        }
    } else if ($_POST['type'] == 'dpp') {
        // Processing Form Data
        if ($_POST['type'] == 'dpp') {
            if (isset($_POST['iv']) && isset($_POST['dr'])) {
                $iv = $_POST['iv'];
                $dr = $_POST['dr'];
                $years = count($_POST['yr']);
                $userId = $_SESSION['id'];

                // Calculating DPP
                array_push($dpp_array, [0, $iv, $iv, 1, $iv, $iv]);
                $initial_cf = $_POST['iv'];
                $initial_ccf = $_POST['iv'];

                for ($i = 0; $i < $years; $i++) {

                    $cf = $_POST['yr'][$i];
                    $ncf = $initial_cf - $cf;
                    $pv = round(1 / pow((1 + ($dr / 100)), ($i + 1)), 2);
                    $dcf = $cf * $pv;
                    $ccf = $initial_ccf - $dcf;

                    array_push($dpp_array, [($i + 1), $cf, $ncf, $pv, $dcf, $ccf]);
                    // Resetting value
                    $initial_cf = $cf;
                    $initial_ccf = $ccf;
                }
            }
        }
    }
}


?>