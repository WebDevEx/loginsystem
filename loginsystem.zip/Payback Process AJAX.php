<?php

if(!isset($_SESSION)){
	
session_start();

}

$_SESSION['CompanyA']=0;
$_SESSION['CompanyB']=0;
$_SESSION['CompanyC']=0;
$_SESSION['CompanyAYear']=0;
$_SESSION['CompanyBYear']=0;
$_SESSION['CompanyCYear']=0;
$MSG='';

?>

<?php

#COMPANY A SOURCE CODES

    // Processing Form Data
if ($_POST['type'] == 'dpp') {
	
	$dpp_array = [];
	
        // Processing Form Data
        if ($_POST['type'] == 'dpp') {
			
            if (isset($_POST['iv']) && isset($_POST['dr'])) {
                $iv = $_POST['iv'];
                $dr = $_POST['dr'];
				
				$yr=$_POST['yr'];
				$yr=implode(",",$yr);
				$yr=explode(",",$yr);
                $years = count($yr);
                $userId = $_SESSION['id'];

                // Calculating DPP
                array_push($dpp_array, [0, $iv, $iv, 1, $iv, $iv]);
                $initial_cf = $_POST['iv'];
                $initial_ccf = $_POST['iv'];

                for ($i = 0; $i < $years; $i++) {

                    $cf = $yr[$i];
                    $ncf = $initial_cf - $cf;
                    $pv = round(1 / pow((1 + ($dr / 100)), ($i + 1)), 2);
                    $dcf = $cf * $pv;
                    $ccf = $initial_ccf - $dcf;

                    array_push($dpp_array, [($i + 1), $cf, $ncf, $pv, $dcf, $ccf]);
                    // Resetting value
                    $initial_cf = $cf;
                    $initial_ccf = $ccf;
					
                }
            }
        }
    }

#END COMPANY A SOURCE CODES----------------------------------------

#COMPANY B SOURCE CODES

    // Processing Form Data
if ($_POST['type'] == 'dpp2') {
        // Processing Form Data
		
		$dpp_array2 = [];
		
        if ($_POST['type'] == 'dpp2') {
            if (isset($_POST['iv2']) && isset($_POST['dr2'])) {
                $iv2 = $_POST['iv2'];
                $dr2 = $_POST['dr2'];
                $yr2=$_POST['yr2'];
				$yr2=implode(",",$yr2);
				$yr2=explode(",",$yr2);
				$years2 = count($yr2);
                $userId = $_SESSION['id'];

                // Calculating DPP
                array_push($dpp_array2, [0, $iv2, $iv2, 1, $iv2, $iv2]);
                $initial_cf2 = $_POST['iv2'];
                $initial_ccf2 = $_POST['iv2'];

                for ($i2 = 0; $i2 < $years2; $i2++) {

                    $cf2 = $yr2[$i2];
                    $ncf2 = $initial_cf2 - $cf2;
                    $pv2 = round(1 / pow((1 + ($dr2 / 100)), ($i2 + 1)), 2);
                    $dcf2 = $cf2 * $pv2;
                    $ccf2 = $initial_ccf2 - $dcf2;

                    array_push($dpp_array2, [($i2 + 1), $cf2, $ncf2, $pv2, $dcf2, $ccf2]);
                    // Resetting value
                    $initial_cf2 = $cf2;
                    $initial_ccf2 = $ccf2;
                }
            }
        }
    }

#END COMPANY B SOURCE CODES----------------------------------------


#COMPANY C SOURCE CODES

    // Processing Form Data
if ($_POST['type'] == 'dpp3') {
        // Processing Form Data
		
		$dpp_array3 = [];
		
        if ($_POST['type'] == 'dpp3') {
            if (isset($_POST['iv3']) && isset($_POST['dr3'])) {
                $iv3 = $_POST['iv3'];
                $dr3 = $_POST['dr3'];
                $yr3=$_POST['yr3'];
				$yr3=implode(",",$yr3);
				$yr3=explode(",",$yr3);
				$years3 = count($yr3);
                $userId = $_SESSION['id'];

                // Calculating DPP
                array_push($dpp_array3, [0, $iv3, $iv3, 1, $iv3, $iv3]);
                $initial_cf3 = $_POST['iv3'];
                $initial_ccf3 = $_POST['iv3'];

                for ($i3 = 0; $i3 < $years3; $i3++) {

                    $cf3 = $yr3[$i3];
                    $ncf3 = $initial_cf3 - $cf3;
                    $pv3 = round(1 / pow((1 + ($dr3 / 100)), ($i3 + 1)), 2);
                    $dcf3 = $cf3 * $pv3;
                    $ccf3 = $initial_ccf3 - $dcf3;

                    array_push($dpp_array3, [($i3 + 1), $cf3, $ncf3, $pv3, $dcf3, $ccf3]);
                    // Resetting value
                    $initial_cf3 = $cf3;
                    $initial_ccf3 = $ccf3;
                }
            }
        }
    }

#END COMPANY C SOURCE CODES----------------------------------------


?>

<?php
if ($_POST['type'] == 'dpp') {
?>

 <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Year</th>
                        <th>CF</th>
                        <th>NCF</th>
                        <th>PV Factor</th>
                        <th>DCF</th>
                        <th>CCF</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (count($dpp_array) == 0) {
                        echo "<tr><td colspan='6'>No Record Found</td></tr>";
                    } else {
                        foreach ($dpp_array as $list) {
							
				         $vr=array();
						 $vr[]=$list[2];
						 $yr=array();
						 $yr[]=$list[0];
						 
			
                            echo "<tr>
                         <td>" . $list[0] . "</td>
                         <td>" . number_format($list[1],2,'.',',') . "</td>
                         <td>" . number_format($list[2],2,'.',',') . "</td>
                         <td>" . $list[3] . "</td>
                         <td>" . number_format($list[4],2,'.',',') . "</td>
                         <td>" . number_format($list[5],2,'.',',') . "</td>
                    </tr>";
                        }
						$_SESSION['CompanyA']=min($vr);
						$_SESSION['CompanyAYear']=min($yr);
						
                    }
                    ?>
                </tbody>
            </table>


<?php }?>




<?php
if ($_POST['type'] == 'dpp2') {
?>

<table class="table table-striped">
                <thead>
                    <tr>
                        <th>Year</th>
                        <th>CF</th>
                        <th>NCF</th>
                        <th>PV Factor</th>
                        <th>DCF</th>
                        <th>CCF</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (count($dpp_array2) == 0) {
                        echo "<tr><td colspan='6'>No Record Found</td></tr>";
                    } else {
                        foreach ($dpp_array2 as $list2) {
							
						 $vr=array();
						 $vr[]=$list2[2];
						 $yr=array();
						 $yr[]=$list2[0];
							
                            echo "<tr>
                        <td>" . $list2[0] . "</td>
                         <td>" . number_format($list2[1],2,'.',',') . "</td>
                         <td>" . number_format($list2[2],2,'.',',') . "</td>
                         <td>" . $list2[3] . "</td>
                         <td>" . number_format($list2[4],2,'.',',') . "</td>
                         <td>" . number_format($list2[5],2,'.',',') . "</td>
                    </tr>";
                        }
						$_SESSION['CompanyB']=min($vr);
                        $_SESSION['CompanyBYear']=min($yr);
						
                    }
                    ?>
                </tbody>
            </table>

<?php }?>


<?php
if ($_POST['type'] == 'dpp3') {
?>

<table class="table table-striped">
                <thead>
                    <tr>
                        <th>Year</th>
                        <th>CF</th>
                        <th>NCF</th>
                        <th>PV Factor</th>
                        <th>DCF</th>
                        <th>CCF</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (count($dpp_array3) == 0) {
                        echo "<tr><td colspan='6'>No Record Found</td></tr>";
                    } else {
                        foreach ($dpp_array3 as $list3) {
							
							$vr=array();
                            $vr[]=$list3[2];
                            $yr=array();
                            $yr[]=$list3[0];
							
                            echo "<tr>
                        <td>" . $list3[0] . "</td>
                         <td>" . number_format($list3[1],2,'.',',') . "</td>
                         <td>" . number_format($list3[2],2,'.',',') . "</td>
                         <td>" . $list3[3] . "</td>
                         <td>" . number_format($list3[4],2,'.',',') . "</td>
                         <td>" . number_format($list3[5],2,'.',',') . "</td>
                    </tr>";
                        }
						
						$_SESSION['CompanyC']=min($vr);
                        $_SESSION['CompanyCYear']=min($yr);
						
                    }
                    ?>
                </tbody>
            </table>

<?php }?>

<?php
if ($_POST['type'] == 'dpp3') {
	
	if($_SESSION['CompanyA']<$_SESSION['CompanyB'] && $_SESSION['CompanyA']<$_SESSION['CompanyC']){
	$MSG='Company A has the Best Performance DPP of: '.'K'.number_format($_SESSION['CompanyA'],2,".",",").' under Year: '.$_SESSION['CompanyAYear']; 
 }
 
 if($_SESSION['CompanyB']<$_SESSION['CompanyA'] && $_SESSION['CompanyB']<$_SESSION['CompanyC']){
	$MSG='Company B has the Best Performance DPP of: '.'K'.number_format($_SESSION['CompanyB'],2,".",",").' under Year: '.$_SESSION['CompanyBYear']; 
 }
 
 if($_SESSION['CompanyC']<$_SESSION['CompanyB'] && $_SESSION['CompanyC']<$_SESSION['CompanyA']){
	$MSG='Company C has the Best Performance DPP of: '.'K'.number_format($_SESSION['CompanyC'],2,".",",").' under Year: '.$_SESSION['CompanyCYear']; 
 }
 
 echo $MSG;
 echo $_SESSION['CompanyB'];
	
	
	 } ?>