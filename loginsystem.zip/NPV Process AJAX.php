<?php
if(!isset($_SESSION)){
session_start();	
}
?>
<?php
include 'dbconnection.php';
ini_set('display_errors','off');

$_SESSION['CompanyA']=0;
$_SESSION['CompanyB']=0;
$_SESSION['CompanyC']=0;
$MSG='';

#COMPANY A SOURCE CODES

   function npv($rate, $values, $year)
{
    $npv = 0;
    for ($i = $year; $i >= 0; $i -= 1) {
        $npv = ($values[$i] + $npv) / (1 + $rate);
    }
    return number_format($npv, 2, '.', ',');
}

    // Processing Form Data
    if ($_POST['type'] == 'npp') {
        if (isset($_POST['iv']) && isset($_POST['dr'])) {
             // Calculating NPP
            $NPV = npv($_POST['dr'], $_POST['yr'], count($_POST['yr']));
			
			$NPV=str_replace(',','',$NPV);
            $iv = $_POST['iv'];
            $dr = $_POST['dr'];
            $years = count($_POST['yr']);
            $userId = $_SESSION['id'];
			
			$_SESSION['CompanyA']=$NPV;

            // Inserting data into database
            $sql = "INSERT INTO npv (Company,initial_investment, discount_rate, years, npv, userID)
                    VALUES ('A','$iv', '$dr', '$years', '$NPV', '$userId')";

            $con->query($sql);
        }
    }


#END COMPANY A SOURCE CODES----------------------------------------

#COMPANY B SOURCE CODES

function npv2($rate, $values, $year)
{
    $npv = 0;
    for ($i = $year; $i >= 0; $i -= 1) {
        $npv = ($values[$i] + $npv) / (1 + $rate);
    }
    return number_format($npv, 2, '.', ',');
}

    // Processing Form Data
    if ($_POST['type'] == 'npp2') {
        if (isset($_POST['iv2']) && isset($_POST['dr2'])) {
            // Calculating NPP
            $NPV = npv2($_POST['dr2'], $_POST['yr2'], count($_POST['yr2']));
			$NPV=str_replace(',','',$NPV);
            $iv = $_POST['iv2'];
            $dr = $_POST['dr2'];
            $years = count($_POST['yr2']);
            $userId = $_SESSION['id'];
			
			$_SESSION['CompanyB']=$NPV;

            // Inserting data into database
            $sql = "INSERT INTO npv (Company,initial_investment, discount_rate, years, npv, userID)
                    VALUES ('B',$iv, $dr, $years, $NPV, $userId)";

            $con->query($sql);
        }
    }


#END COMPANY B SOURCE CODES----------------------------------------


#COMPANY C SOURCE CODES

   function npv3($rate, $values, $year)
{
    $npv = 0;
    for ($i = $year; $i >= 0; $i -= 1) {
        $npv = ($values[$i] + $npv) / (1 + $rate);
    }
    return number_format($npv, 2, '.', ',');
}

    // Processing Form Data
    if ($_POST['type'] == 'npp3') {
        if (isset($_POST['iv3']) && isset($_POST['dr3'])) {
            // Calculating NPP
            $NPV = npv3($_POST['dr3'], $_POST['yr3'], count($_POST['yr3']));
			$NPV=str_replace(',','',$NPV);
            $iv = $_POST['iv3'];
            $dr = $_POST['dr3'];
            $years = count($_POST['yr3']);
            $userId = $_SESSION['id'];
			
			$_SESSION['CompanyC']=$NPV;

            // Inserting data into database
            $sql = "INSERT INTO npv (Company,initial_investment, discount_rate, years, npv, userID)
                    VALUES ('C',$iv, $dr, $years, $NPV, $userId)";

            $con->query($sql);

        }
    }

#END COMPANY C SOURCE CODES----------------------------------------


?>

<?php
#COMPANY A DATA
 if ($_POST['type'] == 'npp') {
	 
	 // Fetching NPP data
$sql = "SELECT * FROM npv where userID = " . $_SESSION['id']." AND Company='A'";
$result = $con->query($sql);
$npv_list = [];
$dpp_array = [];

if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        array_push($npv_list, $row);
    }
}
 
 ?>
 
 <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Initial Investment</th>
                        <th>Discount Rate(%)</th>
                        <th>NPV</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (count($npv_list) == 0) {
                        echo "<tr><td colspan='3'>No Record Found</td></tr>";
                    } else {
                        foreach ($npv_list as $list) {
                            echo "<tr>
                         <td>" . number_format($list['initial_investment'],2,'.',',') . "</td>
                         <td>" . $list['discount_rate'] . "</td>
                         <td>" . number_format($list['npv'],2,'.',',') . "</td>
                    </tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
 
 <?php } ?>
 
 
 <?php
#COMPANY B DATA
 if ($_POST['type'] == 'npp2') {
	 
	 // Fetching NPP2 data
$sql2 = "SELECT * FROM npv where userID = " . $_SESSION['id']." AND Company='B'";
$result2 = $con->query($sql2);
$npv_list2 = [];
$dpp_array2 = [];

if ($result2->num_rows > 0) {
    // output data of each row
    while ($row2 = $result2->fetch_assoc()) {
        array_push($npv_list2, $row2);
    }
}
 
 ?>
 
  <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Initial Investment</th>
                        <th>Discount Rate(%)</th>
                        <th>NPV</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (count($npv_list2) == 0) {
                        echo "<tr><td colspan='3'>No Record Found</td></tr>";
                    } else {
                        foreach ($npv_list2 as $list2) {
                            echo "<tr>
                         <td>" . number_format($list2['initial_investment'],2,'.',',') . "</td>
                         <td>" . $list2['discount_rate'] . "</td>
                         <td>" . number_format($list2['npv'],2,'.',',') . "</td>
                    </tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
 
 
 <?php } ?>
 
 
 <?php
#COMPANY C DATA
 if ($_POST['type'] == 'npp3') {
	 
	 // Fetching NPP3 data
$sql3 = "SELECT * FROM npv where userID = " . $_SESSION['id']." AND Company='C'";
$result3 = $con->query($sql3);
$npv_list3 = [];
$dpp_array3 = [];

if ($result3->num_rows > 0) {
    // output data of each row
    while ($row3 = $result3->fetch_assoc()) {
        array_push($npv_list3, $row3);
    }
}
 
 ?>
 
 <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Initial Investment</th>
                        <th>Discount Rate(%)</th>
                        <th>NPV</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (count($npv_list3) == 0) {
                        echo "<tr><td colspan='3'>No Record Found</td></tr>";
                    } else {
                        foreach ($npv_list3 as $list3) {
                            echo "<tr>
                         <td>" . number_format($list3['initial_investment'],2,'.',',') . "</td>
                         <td>" . $list3['discount_rate'] . "</td>
                         <td>" . number_format($list3['npv'],2,'.',',') . "</td>
                    </tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
 
 
 <?php } ?>
 
 <?php
 
 if ($_POST['type'] == 'npp3') {
 
 if($_SESSION['CompanyA']>$_SESSION['CompanyB'] && $_SESSION['CompanyA']>$_SESSION['CompanyC']){
	$MSG='Company A has the Best Performance NPV of: '.'K'.number_format($_SESSION['CompanyA'],2,".",","); 
 }
 
 if($_SESSION['CompanyB']>$_SESSION['CompanyA'] && $_SESSION['CompanyB']>$_SESSION['CompanyC']){
	$MSG='Company B has the Best Performance NPV of: '.'K'.number_format($_SESSION['CompanyB'],2,".",","); 
 }
 
 if($_SESSION['CompanyC']>$_SESSION['CompanyB'] && $_SESSION['CompanyC']>$_SESSION['CompanyA']){
	$MSG='Company C has the Best Performance NPV of: '.'K'.number_format($_SESSION['CompanyC'],2,".",","); 
 }
 
 echo $MSG;
 
 ?>
 
 <?php } ?>
