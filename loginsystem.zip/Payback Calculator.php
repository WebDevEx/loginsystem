<?php
session_start();
if (strlen($_SESSION['id'] == 0)) {
    header('location:NPV.php');
}

include 'dbconnection.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>NPV CALCULATOR</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    

</head>

<body>
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="welcome.php"><strong>Dashboard</strong></a>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">


                </ul>
            </div>
        </div>
    </nav>

    <div class="container panel panel-default panel-body" style="width:100%;">

     <p class="h3 text-muted" style="text-align:center;">Discounted Payback Period Calculator</p>
        <div class="text-center table-responsive col-md-7" style="width:50%;">

            <h1 style="font-weight:bold;">Company A</h1>
       

            <form method="post" action="">
                <table class="table table-condensed table-striped table-bordered" id="tab_logic_dpp">
                    <tbody>
                        <tr>
                            <td>
                                Initial Investment:
                                <input type="hidden" name="type" id="dpp" value="dpp">
                            </td>
                            <td>
                                <input type="number" class="form-control" name="iv" id="iv" required>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Discount Rate % :
                            </td>
                            <td>
                               <input type="number" step="0.01" class="form-control" name="dr" id="dr"  required> 
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="bg-info">
                                <strong>Annual Cash Flow</strong>
                            </td>
                        </tr>

                  <td>
                            Year 1
                    </td>
                        <td>
                            <input name="yr[]" id="yr"  class="form-control" required />
                        </td>
                        </tr>
                        <!-- 
                        <tr id='addr0'>
                            <td>
                                Year 2
                            </td>
                            <td>
                                <input name="yr[]"  class="form-control" required />
                            </td>
                        </tr>
                        <tr id='addr1'>
                            <td>
                                Year 3
                            </td>
                            <td>
                                <input name="yr[]"  class="form-control" required />
                            </td>
                        </tr>
                        <tr id='addr2'>
                        </tr> -->

                    <td height="2"></tbody>

                </table>
                <table class="table table-condensed table-striped table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2">
                                <span>
                                    <a>
                                        <input type="button" id="addRow" value="Add another Year" onclick="addRowPeriodDPP()" />
                                    </a>
                                    <a>


                                    </a>
                                    <!-- <a>
                                        <input type="button" id="bt" value="Delete Period" onclick="submit()" />
                                    </a> -->


                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <p>
                                    <input type="button" id="bt" value="Calculate" />
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>

<div id="DPPData">

<!--DPP Data will be Displayed Here-->

</div>
           
        </div>

<!---------------------COMPANY B---------------------------------->

<div class="text-center table-responsive col-md-7" style="width:50%;">

            <h1 style="font-weight:bold;">Company B</h1>


            <form method="post" action="">
                <table class="table table-condensed table-striped table-bordered" id="tab_logic_dpp2">
                    <tbody>
                        <tr>
                            <td>
                                Initial Investment:
                                <input type="hidden" name="type" id="dpp2" value="dpp2">
                            </td>
                            <td>
                                <input type="number" class="form-control" name="iv2" id="iv2" required>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Discount Rate % :
                            </td>
                            <td>
                                <input type="number" step="0.01" class="form-control" name="dr2" id="dr2"  required>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="bg-info">
                                <strong>Annual Cash Flow</strong>
                            </td>
                        </tr>

                  <td>
                            Year 1
                    </td>
                        <td>
                            <input name="yr2[]"  class="form-control" id="yr2" required />
                        </td>
                        </tr>
                        <!-- 
                        <tr id='addr0'>
                            <td>
                                Year 2
                            </td>
                            <td>
                                <input name="yr[]"  class="form-control" required />
                            </td>
                        </tr>
                        <tr id='addr1'>
                            <td>
                                Year 3
                            </td>
                            <td>
                                <input name="yr[]"  class="form-control" required />
                            </td>
                        </tr>
                        <tr id='addr2'>
                        </tr> -->

                    <td height="2"></tbody>

                </table>
                <table class="table table-condensed table-striped table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2">
                                <span>
                                    <a>
                                        <input type="button" id="addRow2" value="Add another Year" onclick="addRowPeriodDPP2()" />
                                    </a>
                                    <a>


                                    </a>
                                    <!-- <a>
                                        <input type="button" id="bt" value="Delete Period" onclick="submit()" />
                                    </a> -->


                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td height="35" colspan="2">
                                <p>
                                    <input type="button" id="bt2" value="Calculate" />
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>

<div id="DPPData2">

<!--DPP Data 2 will be Displayed Here-->

</div>
            

        </div>

<!---------------------------------------------------------------->


<!---------------------COMPANY C---------------------------------->

<div class="text-center table-responsive col-md-7" style="width:50%;">

            <h1 style="font-weight:bold;">Company C</h1>

            <form method="post" action="">
                <table class="table table-condensed table-striped table-bordered" id="tab_logic_dpp3">
                    <tbody>
                        <tr>
                            <td>
                                Initial Investment:
                                <input type="hidden" name="type" id="dpp2" value="dpp3">
                            </td>
                            <td>
                                <input type="number" class="form-control" name="iv3" id="iv3" required>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Discount Rate % :
                            </td>
                            <td>
                                <input type="number" step="0.01" class="form-control" name="dr3" id="dr3"  required>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="bg-info">
                                <strong>Annual Cash Flow</strong>
                            </td>
                        </tr>

                  <td>
                            Year 1
                    </td>
                        <td>
                            <input name="yr3[]"  class="form-control" id="yr3" required />
                        </td>
                        </tr>
                        <!-- 
                        <tr id='addr0'>
                            <td>
                                Year 2
                            </td>
                            <td>
                                <input name="yr[]"  class="form-control" required />
                            </td>
                        </tr>
                        <tr id='addr1'>
                            <td>
                                Year 3
                            </td>
                            <td>
                                <input name="yr[]"  class="form-control" required />
                            </td>
                        </tr>
                        <tr id='addr2'>
                        </tr> -->

                    <td height="2"></tbody>

                </table>
                <table class="table table-condensed table-striped table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2">
                                <span>
                                    <a>
                                        
                                    </a>
                                    <a>
<input type="button" id="addRow3" value="Add another Year" onclick="addRowPeriodDPP3()" />

                                    </a>
                                    <!-- <a>
                                        <input type="button" id="bt" value="Delete Period" onclick="submit()" />
                                    </a> -->


                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td height="35" colspan="2">
                                <p>
                                    <input type="button" id="bt3" value="Calculate" />
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>

<div id="DPPData3">

<!--DPP Data 2 will be Displayed Here-->

</div>
            

        </div>

<!---------------------------------------------------------------->
    </div>

</body>

 <script src="js/jquery.js"></script>
 <script type="text/javascript" src="Payback AJAX.js"> </script>
 
 <script>
 
$(document).ready(function(){
	
$('title').html('DPP Calculator');

$(document).on('keyup','#iv',function(){
	$('#iv2').val($('#iv').val());
	$('#iv3').val($('#iv').val());
});

$(document).on('keyup','#iv2',function(){
	$('#iv').val($('#iv2').val());
	$('#iv3').val($('#iv2').val());
});

$(document).on('keyup','#iv3',function(){
	$('#iv2').val($('#iv3').val());
	$('#iv').val($('#iv3').val());
});

//--------------------------
$(document).on('keyup','#dr',function(){
	$('#dr2').val($('#dr').val());
	$('#dr3').val($('#dr').val());
});

$(document).on('keyup','#dr2',function(){
	$('#dr').val($('#dr2').val());
	$('#dr3').val($('#dr2').val());
});

$(document).on('keyup','#dr3',function(){
	$('#dr2').val($('#dr3').val());
	$('#dr').val($('#dr3').val());
});

function ProcessDPP(){

	var Type='dpp';
	var iv=$('#iv').val();
	var dr=$('#dr').val();
	var yr = $("input[name='yr[]']")
              .map(function(){return $(this).val();}).get();

$.ajax({
				
			type: "POST",
			url: "Payback Process AJAX.php",
			data: {
                   type: Type,
                   iv: iv,
                   dr: dr,
                   yr: yr
			},
			
			error: function(response){
				$('#DPPData').html('');
				$('#DPPData').html(response);
			},
			
	success: function(response){
	$('#DPPData').html('');
	$('#DPPData').html(response);
	
	}

				
			});

}


function ProcessDPP2(){

	var Type='dpp2';
	var iv2=$('#iv2').val();
	var dr2=$('#dr2').val();
	var yr2 = $("input[name='yr2[]']")
              .map(function(){return $(this).val();}).get();
    
$.ajax({
				
			type: "POST",
			url: "Payback Process AJAX.php",
			data: {
                   type: Type,
                   iv2: iv2,
                   dr2: dr2,
                   yr2: yr2
			},
			
			error: function(response){
				$('#DPPData2').html('');
				$('#DPPData2').html(response);
			},
			
	success: function(response){
	$('#DPPData2').html('');
	$('#DPPData2').html(response);
	
	}

				
			});

}


function ProcessDPP3(){

	var Type='dpp3';
	var iv3=$('#iv3').val();
	var dr3=$('#dr3').val();
	var yr3 = $("input[name='yr3[]']")
              .map(function(){return $(this).val();}).get();
    
$.ajax({
				
			type: "POST",
			url: "Payback Process AJAX.php",
			data: {
                   type: Type,
                   iv3: iv3,
                   dr3: dr3,
                   yr3: yr3
			},
			
			error: function(response){
				$('#DPPData3').html('');
				$('#DPPData3').html(response);
			},
			
	success: function(response){
	$('#DPPData3').html('');
	$('#DPPData3').html(response);
	
	}

				
			});

}

//COMPANY A PROCESSING

$(document).on('click','#bt',function(){
ProcessDPP();
});

//END COMPANY A PROCESSING

//COMPANY B PROCESSING

$(document).on('click','#bt2',function(){	
	ProcessDPP2()
});

//END COMPANY B PROCESSING

//COMPANY C PROCESSING

$(document).on('click','#bt3',function(){	
	ProcessDPP3()
});

//END COMPANY C PROCESSING

});

 
 </script>
</html>