<?php
$string =  <!DOCTYPE html>.
html lang="en">.
<head>.
   <meta charset="utf-8">.
   <meta http-equiv="X-UA-Compatible" content="IE=edge">.
   <meta name="viewport" content="width=device-width, initial-scale=1">.
   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->.
   <meta name="description" content="NPV Calculator is a free online tool to calculate.
     NPV or Net Present Value of your project and investment for a series of cash flow.">.
   <title>NPV Calculator - Calculate Net Present Value Online</title>.
   <link rel="icon" href="/static/images/favicon.ico">.
   <link href="/static/css/bootstrap.min.css" rel="stylesheet">.
   <link href="/static/css/style.css" rel="stylesheet">.
   <meta name="google-site-verification" content="ro2IXJZbyiOalwnFpmLqXdpPW_mhXcUH2FO-AaVueMY" />.
/head>.
<body>.
   <nav class="navbar navbar-default navbar-static-top">.
       <div class="container">.
            <div class="navbar-header">.
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">.
                   <span class="sr-only">Toggle navigation</span>.
                   <span class="icon-bar"></span>.
                   <span class="icon-bar"></span>.
                   <span class="icon-bar"></span>.
               </button>.
               <a class="navbar-brand" href="/"><strong>NPV Calculator</strong></a>.
           </div>.
           <div id="navbar" class="collapse navbar-collapse">.
               <ul class="nav navbar-nav navbar-right">.
                    <li>.
                       <a href="/"><strong>NPV Calculator</strong></a>.
                   </li>.
                    <li>.
                       <a href="/npv-vs-irr/">.
                           <Strong>NPV vs IRR</Strong> </a>.
                   </li>.
                   <li>.
                       <a href="http://irrcalculator.net/" target="_blank" rel="nofollow"><strong>IRR Calculator</strong></a>.
                   </li>.
                   <li>.
                       <a href="http://cagrcalculator.net/" target="_blank" rel="nofollow"><strong>CAGR Calculator</strong></a>.
                   </li>.
                </ul>.
           </div>.
           <!--/.nav-collapse -->.
        </div>.
    </nav>.
    <div class="container panel panel-default panel-body ">.
        <div class="text-center">.
           <h1>NPV Calculator</h1>.
           <p class="h3 text-muted">Calculate NPV or Net Present Value Online</p>.
       </div>.
        <div class="text-center table-responsive col-md-6 col-md-offset-3">.
           <form method="post" action="/result/">.
                <table class="table table-condensed table-striped table-bordered" id="tab_logic">.
                   <tbody>.
                       <tr>.
                           <td>.
                               Initial Investment.
                           </td>.
                           <td>.
                               <input class="form-control" name="iv" placeholder="10000" required>.
                           </td>.
                       </tr>.
                        <tr>.
                           <td>.
                               Discount Rate (% p.a).
                           </td>.
                           <td>.
                               <input type="number" step="0.01" class="form-control" name="dr" placeholder="8.5" required>.
                           </td>.
                       </tr>.
                       <tr>.
                           <td colspan="2" class="bg-info">.
                               <strong>Cash Flow (positive or negative)</strong>.
                           </td>.
                       </tr>.
                        <tr id='addr0'>.
                           <td>.
                               Period 1.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                       </tr>.
                        <tr id='addr1'>.
                           <td>.
                               Period 2.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                           </td>.
                       </tr>.
                        <tr id='addr2'>.
                           <td>.
                               Period 3.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                           </td>.
                       </tr>.
                        <tr id='addr3'>.
                           <td>.
                               Period 4.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                           </td>.
                       </tr>.
                        <tr id='addr4'>.
                           <td>.
                               Period 5.
                           </td>.
                           <td>.
                               <input name="yr" placeholder='0' class="form-control" required/>.
                           </td>.
                       </tr>.
                        <tr id='addr5'>.
                        </tr>.
                    </tbody>.
               </table>.
                <table class="table table-condensed table-striped table-bordered">.
                    <tbody>.
                       <tr>.
                           <td colspan="2">.
                                <span>   .
                          <a id="add_row" class="btn btn-primary"> Add Period</a>.
                          <a id='delete_row' class="btn btn-primary">.
                          Delete Period</a>.
                          </span>.
                            </td>.
                       </tr>.
                        <tr>.
                           <td colspan="2">.
                               <input class="btn btn-primary" type="submit" name="submit" value="Calculate" />.
                           </td>.
                       </tr>.
                    </tbody>.
               </table>.
            </form>.
        </div>.
    </div>.
    <div class="container text-center" style="padding-bottom:15px;">.
        <p class="btn btn-default"> Share on </p>.
        <a href="https://plus.google.com/share?url=http://npvcalculator.info/" target="_blank" class="btn btn-danger">Google+</a>.
       <a href="https://twitter.com/share?url=http://npvcalculator.info/&text= NPV Calculator" target="_blank" class="btn btn-info">Twitter</a>.
       <a href="http://www.facebook.com/sharer.php?u=http://npvcalculator.info" target="_blank" class="btn btn-primary">Facebook</a>.
    </div>.
    <!-- Social Share -->.
    <div class="container panel panel-default panel-body ">.
       <h2>What is NPV or Net Present Value ?</h2>.
       <p>NPV or Net Present Value is a financial metric in capital budgeting that is used to evaluate whether a project or an investment is going to yield good return in future or not. It can be simply represented as the difference between the present value of cash inflows and the present value of cash outflows. In the long run a positive NPV value indicates good potential return over investment, while the negative NPV value means that the investment is likely to loose money. Sometimes NPV is also referred as NPW or Net Present Worth.</p>.
        <h2>NPV calculation formula :</h2>.
       <p>.
           For calculating NPV value using formula, you must already know the estimated value of discount rate (r) , all cash flow (both positive and negative) and the total initial invesment made by the company. The formula for calculating NPV is as follows:.
       </p>.
       <p><img class="img-responsive" src="/static/images/npv-formula.png" alt="NPV Formula" /></p>.
       <p>Where in the above formula :</p>.
       <p>N = total number of periods</p>.
       <p><i>n</i> = positive integer</p>.
       <p>C = cash flow </p>.
       <p>r = discount rate</p>.
       <p>NPV = net present value</p>.
        <h2>Calculate NPV with Example :</h2>.
       <p>Suppose a company wants to start a new manufacturing plant in the near future. The company is looking forward to invest a total sum of $100000 in it's setup at the beginnning, where the expected discount rate is 10 percent per-annum. This company has set it's goal for 5 years and for these 5 years the cash flows are - $10000, $20000, $30000, $40000, $50000 respectively. Let's calculate the NPV and also evaluate whether the company should pursue this decision or not.</p>.
       <p>The equation we have :</p>.
       <p class="h4"> NPV = C<sub>1</sub>/(1+r) + C<sub>2</sub>/(1+r)<sup><sub>2</sub></sup> + C<sub>3</sub>/(1+r)<sup><sub>3</sub></sup> + C<sub>4</sub>/(1+r)<sup><sub>4</sub></sup> + C<sub>5</sub>/(1+r)<sup><sub>5</sub></sup> - initial investment</p>.
        <p>Let's apply all the known values in the NPV formula here. </p>.
        <p class="h4"> NPV = 10000/(1+0.1) + 20000/(1+0.1)<sup><sub>2</sub></sup> + 30000/(1+0.1)<sup><sub>3</sub></sup> + 40000 /(1+0.1)<sup><sub>4</sub></sup> + 50000/(1+0.1)<sup><sub>5</sub></sup> - 100000</p>.
       <p class="h4">NPV = 6525.88 </p>.
       <p>The positive value of NPV suggests the investment is likely to return profit in the future. In this scenario the NPV is 6525.88, so it seems that the investment is likely to yield profit.</p>.
       <h2>NPV decision rule :</h2>.
       <p>If <strong>NPV > 0 </strong>, then the company should accept the investment decision or project. The positive value of NPV is expected to increase the net worth of the company or it's shareholders. </p>.
       <p>If <strong>NPV < 0 </strong>, the company is expected to loose the money, so it shouldn't pursue that investment or project. </p>.
       <p>If <strong>NPV = 0 </strong>, this will neither increase or decrease the value of the company or firm.</p>.
        <h2>Drawbacks of NPV : </h2>.
       <p>The <strong>discount rates</strong> (r) used in the formula above are likely to vary over time. The slight increase or decrease in discount rate can impact the NPV value. Hence it's critical in decision making.</p>.
       <p>NPV is not effective in comparing two mutually exclusive projects which require different amount of investment.</p>.
       <p>NPV may not give correct decision when comapring two projects with different time duration.</p>.
       <p>NPV calculation is based upon assumptions. It's prone to forcasting error. So, companies can't rely on only NPV before making any investment decision. There's other financial tool too (like IRR or Internal rate of return) which companies should consider for getting the clear pictures.</p>.
       <div class="bg-info">.
       <p><strong><u> Further Reading Suggestions:</u></strong></p>.
       <ul>.
           <li> .
           <a href="/npv-vs-irr/"><strong>NPV vs IRR</strong></a>: Which is better for capital budgeting?.
           </li>.
           <li>.
               <a href="/npv-calculation-in-excel/">NPV calculation in excel</a>.
           </li>.
       </ul>.
       </div>.
        <h2>About this NPV Calculator</h2>.
       <p>Calculating NPV can be a very daunting task, specially when you have so many positive and negative cash flows. There's many tool available that can be used to calculate NPV. You can either use financial calculators like Ti-83,Ti-84 and HP 12c calculator or can take the help from softwares like MS Excel. This website,<strong> npvcalculator.info </strong> is such tool. It's an online NPV calculator..
       <p> To calculate NPV or Net Present Value, enter the initial investment, the expected discount rate and cash flows for each period. You can also add or delete period fields as needed. Then hit the calculate button to get the NPV result.</p>.
        <div class="bg-info">.
       <p><strong><u>Our Other Financial Calculators:</u></strong>.
       </p>.
       <ul>.
           <li><a href="http://sipcalculator.net/" target="_blank" rel="nofollow"><strong>SIP Calculator</strong></a> : To calculate return on mutual fund systematic investment plan..
           </li>.
           <li><a href="http://irrcalculator.net/" target="_blank"><strong>IRR Calculator</strong></a> : To calculate the internal rate of return.
           </li>.
           <li><a href="http://cagrcalculator.net/" target="_blank" rel="nofollow"><strong>CAGR Calculator</strong></a> : To calculate the compound annual growth rate for an investment..
           </li>.
       </ul>.
       </div>.
   </div>.
   <div class="container">.
       <p class="text-muted"><strong>Disclaimer:</strong></p>.
       <em class="text-muted">.
         The NPV Calculator provides "NPV" or "Net Present Value" without any warranty for it's accuracy. Any reliance by you on any information or advice will be at your own risk. Every decisions should be made after consultation with your financial advisor or professional.This website is not responsible for, and expressly disclaims all liability for, damages of any kind arising out of use, reference to, or reliance on any information contained within the site. By using this website you agree to those terms, if not then do not use this website. .
         </em>.
        <hr>.
        <footer class="text-center">.
           <p>&copy; npvcalculator.info (2017) &nbsp;&nbsp;&nbsp; All Rights Reserved.
               <span>&nbsp;&nbsp;&nbsp;.
           <a href="mailto:ambuj.website@gmail.com?subject=About NPV Calculator">Contact</a>.
           </p>.
       </footer>.
   </div>.
    <!-- /.container -->.
    <!-- Bootstrap core JavaScript.
        ================================================== -->.
   <!-- Placed at the end of the document so the pages load faster -->.
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>.
    <script src="/static/js/bootstrap.min.js"></script>.
    <script src="/static/js/script.js"></script>.
   <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->.
   <script src="/static/js/ie10-viewport-bug-workaround.js"></script>.
   <script>.
     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){.
     (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),.
     m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m).
     })(window,document,'script','//www.google-analytics.com/analytics.js','ga');.
      ga('create', 'UA-73695477-1', 'auto');.
     ga('send', 'pageview');.
    </script>.
/body>.
</html>;

 echo $string; 
?>